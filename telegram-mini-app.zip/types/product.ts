export interface Measurement {
  name: string
  value: string
}

export interface Product {
  id: number
  name: string
  price: number
  originalPrice?: number
  image: string
  additionalImages?: string[] // Добавляем поддержку нескольких изображений
  description: string
  category: string
  isNew?: boolean
  isAvailable: boolean
  productLink?: string
  size?: string
  measurements?: Measurement[]
}
