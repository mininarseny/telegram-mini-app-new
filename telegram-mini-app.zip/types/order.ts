import type { Product } from "@/types/product"

export interface OrderItem {
  product: Product
  quantity: number
}

export interface Order {
  id: string
  items: OrderItem[]
  totalAmount: number
  status: "pending" | "completed" | "cancelled"
  date: string
  telegramUserId?: number
  telegramUsername?: string
  paymentMethod: string
  orderNumber: string
}

export interface UserOrderHistory {
  telegramUserId: number
  telegramUsername?: string
  orders: Order[]
}
