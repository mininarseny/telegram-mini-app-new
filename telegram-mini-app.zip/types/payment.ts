export interface PaymentMethod {
  id: number
  name: string
  description: string
  instructions: string
  details: string
  enabled: boolean
}
