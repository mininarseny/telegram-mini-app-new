"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, CreditCard, Loader2 } from "lucide-react"
import { motion } from "framer-motion"
import { useSettings } from "@/contexts/settings-context"

interface YooKassaPaymentProps {
  amount: number
  orderId: string
  onBack: () => void
  onSuccess: () => void
  onCancel: () => void
}

export function YooKassaPayment({ amount, orderId, onBack, onSuccess, onCancel }: YooKassaPaymentProps) {
  const { formatPrice } = useSettings()
  const [isLoading, setIsLoading] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState<"pending" | "success" | "error">("pending")

  // Имитация процесса оплаты
  const handlePayment = () => {
    setIsLoading(true)

    // Имитируем запрос к API ЮKassa
    setTimeout(() => {
      setIsLoading(false)
      setPaymentStatus("success")

      // После успешной оплаты
      setTimeout(() => {
        onSuccess()
      }, 2000)
    }, 3000)
  }

  return (
    <div className="max-w-md mx-auto">
      <Card className="p-6 border-zinc-200 dark:border-zinc-800">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">Оплата заказа</h2>
          <img src="/placeholder.svg?height=30&width=120" alt="ЮKassa" className="h-8" />
        </div>

        {paymentStatus === "pending" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-zinc-500 dark:text-zinc-400">Номер заказа:</span>
                <span className="font-medium">{orderId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500 dark:text-zinc-400">Сумма к оплате:</span>
                <span className="font-bold">{formatPrice(amount)}</span>
              </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-md p-3 text-blue-800 dark:text-blue-200">
              <p className="text-sm">
                Нажмите кнопку "Оплатить" для перехода на страницу безопасной оплаты ЮKassa. После успешной оплаты вы
                будете автоматически перенаправлены обратно.
              </p>
            </div>

            <div className="space-y-3">
              <Button
                onClick={handlePayment}
                disabled={isLoading}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white h-12"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Обработка...
                  </>
                ) : (
                  <>
                    Оплатить {formatPrice(amount)} <CreditCard className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>

              <Button variant="outline" onClick={onBack} disabled={isLoading} className="w-full">
                <ArrowLeft className="mr-2 h-4 w-4" /> Вернуться назад
              </Button>
            </div>

            <div className="flex items-center justify-center space-x-2">
              <img src="/placeholder.svg?height=30&width=40" alt="Visa" className="h-6" />
              <img src="/placeholder.svg?height=30&width=40" alt="MasterCard" className="h-6" />
              <img src="/placeholder.svg?height=30&width=40" alt="Мир" className="h-6" />
            </div>
          </motion.div>
        )}

        {paymentStatus === "success" && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-6"
          >
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 dark:bg-green-900 mb-4">
              <CreditCard className="h-8 w-8 text-green-600 dark:text-green-300" />
            </div>
            <h3 className="text-xl font-bold mb-2">Оплата прошла успешно!</h3>
            <p className="text-zinc-500 dark:text-zinc-400 mb-6">
              Ваш заказ #{orderId} успешно оплачен и принят в обработку
            </p>
          </motion.div>
        )}
      </Card>
    </div>
  )
}
