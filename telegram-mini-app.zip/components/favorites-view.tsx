"use client"

import { motion } from "framer-motion"
import { useFavorites } from "@/contexts/favorites-context"
import { useSettings } from "@/contexts/settings-context"
import { Card, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, Sparkles } from "lucide-react"
import Image from "next/image"

interface FavoritesViewProps {
  onProductSelect: (productId: number) => void
  onBackToProducts: () => void
}

export function FavoritesView({ onProductSelect, onBackToProducts }: FavoritesViewProps) {
  const { favorites, removeFromFavorites } = useFavorites()
  const { formatPrice, t } = useSettings()

  const slideUp = {
    hidden: { y: 20, opacity: 0 },
    visible: (i: number) => ({
      y: 0,
      opacity: 1,
      transition: {
        delay: i * 0.05,
        duration: 0.3,
        type: "spring",
        stiffness: 300,
        damping: 24,
      },
    }),
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-4 space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold flex items-center">
          <Heart className="mr-2 h-5 w-5 fill-red-500 text-red-500" />
          {t("favorites.title")}
        </h2>
        <Button variant="outline" size="sm" onClick={onBackToProducts}>
          {t("favorites.back")}
        </Button>
      </div>

      {favorites.length === 0 ? (
        <div className="text-center py-12 px-4 bg-zinc-50 dark:bg-zinc-900/50 rounded-lg border border-zinc-200 dark:border-zinc-800">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-zinc-100 dark:bg-zinc-800 mb-4">
            <Heart className="h-8 w-8 text-zinc-500 dark:text-zinc-400" />
          </div>
          <h3 className="text-lg font-medium mb-2">{t("favorites.empty")}</h3>
          <p className="text-zinc-500 dark:text-zinc-400 mb-6">{t("favorites.empty_desc")}</p>
          <Button
            onClick={onBackToProducts}
            className="bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
          >
            {t("app.continue_shopping")}
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4">
          {favorites.map((product, i) => (
            <motion.div
              key={product.id}
              custom={i}
              variants={slideUp}
              initial="hidden"
              animate="visible"
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="h-full"
            >
              <Card className="overflow-hidden h-full flex flex-col border-zinc-200 dark:border-zinc-800 shadow-md relative before:absolute before:inset-0 before:z-0 before:border-2 before:border-zinc-100 before:dark:border-zinc-800 before:rounded-lg before:translate-x-1 before:translate-y-1">
                <div className="relative h-[225px]">
                  <Image
                    src={product.image || "/placeholder.svg?height=400&width=300"}
                    alt={product.name}
                    fill
                    className={`object-cover ${!product.isAvailable ? "opacity-50 grayscale" : ""}`}
                    sizes="(max-width: 768px) 100vw, 50vw"
                  />
                  <div className="absolute top-2 left-2 flex flex-col gap-1">
                    {!product.isAvailable && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.2 }}
                        className="px-2 py-1 rounded-md text-xs font-bold bg-zinc-900 text-white dark:bg-zinc-700"
                      >
                        {t("app.sold_out")}
                      </motion.div>
                    )}
                    {product.isNew && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.3 }}
                        className="px-2 py-1 rounded-md text-xs font-bold bg-zinc-900 text-white dark:bg-white dark:text-zinc-900 flex items-center gap-1"
                      >
                        <Sparkles className="h-3 w-3" />
                        NEW
                      </motion.div>
                    )}
                  </div>

                  {/* Добавляем бейдж с размером, если он есть */}
                  {product.size && (
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-zinc-900 text-white dark:bg-white dark:text-zinc-900">{product.size}</Badge>
                    </div>
                  )}

                  {/* Add decorative corner accent */}
                  <div className="absolute top-0 right-0 w-16 h-16 overflow-hidden">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-zinc-900/20 to-transparent transform rotate-45 translate-x-12 -translate-y-12"></div>
                  </div>
                </div>
                <CardHeader className="p-3 flex-1 relative z-10">
                  <CardTitle className="text-sm truncate">{product.name}</CardTitle>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-1">
                      {product.originalPrice ? (
                        <>
                          <Badge
                            variant="outline"
                            className="w-fit bg-zinc-900 text-white border-zinc-900 dark:bg-white dark:text-zinc-900 dark:border-white"
                          >
                            {formatPrice(product.price)}
                          </Badge>
                          <span className="text-xs text-zinc-500 dark:text-zinc-400 line-through">
                            {formatPrice(product.originalPrice)}
                          </span>
                        </>
                      ) : (
                        <Badge variant="outline" className="w-fit border-zinc-200 dark:border-zinc-700">
                          {formatPrice(product.price)}
                        </Badge>
                      )}
                    </div>
                    <Badge
                      variant="secondary"
                      className="text-xs bg-zinc-100 text-zinc-800 dark:bg-zinc-800 dark:text-zinc-200"
                    >
                      {product.category}
                    </Badge>
                  </div>
                </CardHeader>
                <CardFooter className="p-3 pt-0 relative z-10 flex flex-col gap-2">
                  <motion.div whileTap={{ scale: 0.95 }} className="w-full">
                    <Button
                      variant="default"
                      size="sm"
                      className={`w-full ${
                        product.isAvailable
                          ? "bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
                          : "bg-zinc-300 text-zinc-600 dark:bg-zinc-700 dark:text-zinc-300 cursor-not-allowed"
                      }`}
                      onClick={() => product.isAvailable && onProductSelect(product.id)}
                      disabled={!product.isAvailable}
                    >
                      {product.isAvailable ? t("app.details") : t("app.sold_out")}
                    </Button>
                  </motion.div>
                  <motion.div whileTap={{ scale: 0.95 }} className="w-full">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
                      onClick={() => removeFromFavorites(product.id)}
                    >
                      {t("favorites.remove")}
                    </Button>
                  </motion.div>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </motion.div>
  )
}
