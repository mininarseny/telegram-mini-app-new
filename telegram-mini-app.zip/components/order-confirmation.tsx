"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { CheckCircle, MessageCircle, Receipt } from "lucide-react"
import { motion } from "framer-motion"
import { useSettings } from "@/contexts/settings-context"

interface OrderConfirmationProps {
  onBackToShopping: () => void
  adminContact?: string
  orderNumber: string
}

export function OrderConfirmation({ onBackToShopping, adminContact, orderNumber }: OrderConfirmationProps) {
  const { t } = useSettings()

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-4 p-4 max-w-md mx-auto"
    >
      <div className="text-center">
        <div className="flex justify-center mb-4">
          <CheckCircle className="h-16 w-16 text-green-500" />
        </div>
        <h2 className="text-2xl font-bold mb-2">{t("confirmation.title")}</h2>
        <p className="text-zinc-500 dark:text-zinc-400 mb-2">{t("confirmation.desc")}</p>
        <p className="text-zinc-500 dark:text-zinc-400">{t("confirmation.shipping")}</p>
      </div>

      <Card className="p-4 border-zinc-200 dark:border-zinc-800">
        <h3 className="font-medium mb-3 flex items-center">
          <Receipt className="h-5 w-5 mr-2 text-zinc-500" />
          {t("confirmation.order_details")}
        </h3>
        <div className="flex justify-between mb-2">
          <span className="text-sm text-zinc-600 dark:text-zinc-300">{t("confirmation.order_number")}:</span>
          <span className="text-sm font-medium">{orderNumber}</span>
        </div>
        <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-2">{t("confirmation.order_reference")}</p>
      </Card>

      <Card className="p-4 border-zinc-200 dark:border-zinc-800">
        <h3 className="font-medium mb-3 flex items-center">
          <MessageCircle className="h-5 w-5 mr-2 text-zinc-500" />
          {t("confirmation.questions")}
        </h3>
        <p className="text-sm text-zinc-600 dark:text-zinc-300">
          {t("confirmation.contact_admin").replace("{contact}", "@Jericho_Services")}
        </p>
      </Card>

      <Button
        onClick={onBackToShopping}
        className="w-full bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
      >
        {t("confirmation.continue_shopping")}
      </Button>
    </motion.div>
  )
}
