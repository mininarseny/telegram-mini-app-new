"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, X } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { useSettings } from "@/contexts/settings-context"
import type { Product } from "@/types/product"

interface SearchBarProps {
  products: Product[]
  onProductSelect: (product: Product) => void
}

export function SearchBar({ products, onProductSelect }: SearchBarProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [isOpen, setIsOpen] = useState(false)
  const [results, setResults] = useState<Product[]>([])
  const searchRef = useRef<HTMLDivElement>(null)
  const { t } = useSettings()

  // Close search results when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  // Filter products based on search term
  useEffect(() => {
    if (searchTerm.trim() === "") {
      setResults([])
      return
    }

    const filtered = products.filter(
      (product) =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.category.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    setResults(filtered)
  }, [searchTerm, products])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setIsOpen(true)
  }

  const clearSearch = () => {
    setSearchTerm("")
    setResults([])
    setIsOpen(false)
  }

  const handleProductClick = (product: Product) => {
    onProductSelect(product)
    setIsOpen(false)
  }

  return (
    <div className="relative w-full" ref={searchRef}>
      <form onSubmit={handleSearch} className="relative">
        <Input
          type="text"
          placeholder={t("search.placeholder")}
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value)
            if (e.target.value.trim() !== "") {
              setIsOpen(true)
            }
          }}
          className="pr-16 bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800"
        />
        {searchTerm && (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="absolute right-8 top-0 h-full"
            onClick={clearSearch}
          >
            <X className="h-4 w-4" />
          </Button>
        )}
        <Button
          type="submit"
          variant="ghost"
          size="icon"
          className="absolute right-0 top-0 h-full"
          disabled={searchTerm.trim() === ""}
        >
          <Search className="h-4 w-4" />
        </Button>
      </form>

      <AnimatePresence>
        {isOpen && results.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute z-50 mt-1 w-full bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-md shadow-lg max-h-[60vh] overflow-auto"
          >
            <div className="p-2">
              <div className="text-xs text-zinc-500 dark:text-zinc-400 mb-2">
                {results.length} {results.length === 1 ? t("search.result") : t("search.results")}
              </div>
              {results.map((product) => (
                <motion.div
                  key={product.id}
                  whileHover={{ backgroundColor: "rgba(0,0,0,0.05)" }}
                  className="p-2 rounded-md cursor-pointer"
                  onClick={() => handleProductClick(product)}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 bg-zinc-100 dark:bg-zinc-800 rounded-md overflow-hidden relative flex-shrink-0">
                      <img
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{product.name}</div>
                      <div className="text-xs text-zinc-500 dark:text-zinc-400 flex items-center justify-between">
                        <span>{product.category}</span>
                        <span className="font-semibold">{product.price} ₽</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
