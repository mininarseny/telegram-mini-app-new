"use client"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { User, ShoppingBag, Heart, Settings, LogOut } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { useSettings } from "@/contexts/settings-context"
import Image from "next/image"

interface UserProfileProps {
  onViewOrders: () => void
  onViewFavorites: () => void
  onBackToProducts: () => void
}

export function UserProfile({ onViewOrders, onViewFavorites, onBackToProducts }: UserProfileProps) {
  const { user, logout } = useAuth()
  const { t } = useSettings()

  if (!user) {
    return null
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-4 space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold flex items-center">
          <User className="mr-2 h-5 w-5" />
          Профиль
        </h2>
        <Button variant="outline" size="sm" onClick={onBackToProducts}>
          Назад
        </Button>
      </div>

      <Card className="p-4 border-zinc-200 dark:border-zinc-800">
        <div className="flex items-center">
          {user.photo_url ? (
            <div className="relative w-16 h-16 rounded-full overflow-hidden mr-4">
              <Image src={user.photo_url || "/placeholder.svg"} alt={user.first_name} fill className="object-cover" />
            </div>
          ) : (
            <div className="w-16 h-16 bg-zinc-200 dark:bg-zinc-800 rounded-full flex items-center justify-center mr-4">
              <User className="h-8 w-8 text-zinc-500 dark:text-zinc-400" />
            </div>
          )}

          <div>
            <h3 className="font-medium text-lg">
              {user.first_name} {user.last_name || ""}
            </h3>
            {user.username && <p className="text-zinc-500 dark:text-zinc-400">@{user.username}</p>}
            <Badge className="mt-1 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100">
              Telegram ID: {user.id}
            </Badge>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 gap-3">
        <Button variant="outline" className="justify-start h-auto py-3" onClick={onViewOrders}>
          <ShoppingBag className="h-5 w-5 mr-3" />
          <div className="text-left">
            <div className="font-medium">Мои заказы</div>
            <div className="text-xs text-zinc-500 dark:text-zinc-400">История ваших покупок</div>
          </div>
        </Button>

        <Button variant="outline" className="justify-start h-auto py-3" onClick={onViewFavorites}>
          <Heart className="h-5 w-5 mr-3" />
          <div className="text-left">
            <div className="font-medium">Избранное</div>
            <div className="text-xs text-zinc-500 dark:text-zinc-400">Сохраненные товары</div>
          </div>
        </Button>

        <Button variant="outline" className="justify-start h-auto py-3">
          <Settings className="h-5 w-5 mr-3" />
          <div className="text-left">
            <div className="font-medium">Настройки</div>
            <div className="text-xs text-zinc-500 dark:text-zinc-400">Язык, валюта и уведомления</div>
          </div>
        </Button>
      </div>

      <div className="pt-4">
        <Button
          variant="ghost"
          className="w-full text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
          onClick={logout}
        >
          <LogOut className="h-5 w-5 mr-2" />
          Выйти
        </Button>
      </div>
    </motion.div>
  )
}
