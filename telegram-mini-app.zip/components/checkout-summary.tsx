"use client"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ShoppingBag, ChevronRight, Package, CreditCard } from "lucide-react"
import { useSettings } from "@/contexts/settings-context"
import Image from "next/image"
import type { Product } from "@/types/product"

interface CheckoutSummaryProps {
  products: Array<{ product: Product; quantity: number }>
  totalAmount: number
  onProceedToCheckout: () => void
}

export function CheckoutSummary({ products, totalAmount, onProceedToCheckout }: CheckoutSummaryProps) {
  const { formatPrice } = useSettings()

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold flex items-center">
        <ShoppingBag className="h-5 w-5 mr-2" />
        Корзина
      </h2>

      <div className="space-y-3">
        {products.map((item, index) => (
          <Card key={index} className="p-3 border-zinc-200 dark:border-zinc-800">
            <div className="flex">
              <div className="relative w-20 h-20 shrink-0 rounded-lg overflow-hidden">
                <Image
                  src={item.product.image || "/placeholder.svg?height=400&width=300"}
                  alt={item.product.name}
                  fill
                  className="object-cover"
                  sizes="80px"
                />
              </div>
              <div className="flex-1 pl-3">
                <h3 className="font-medium text-sm">{item.product.name}</h3>
                {item.product.size && (
                  <Badge variant="outline" className="text-xs mt-1">
                    Размер: {item.product.size}
                  </Badge>
                )}
                <div className="flex justify-between items-center mt-2">
                  <div className="flex items-center gap-1">
                    <p className="font-semibold">{formatPrice(item.product.price)}</p>
                    {item.product.originalPrice && (
                      <p className="text-xs text-zinc-500 dark:text-zinc-400 line-through">
                        {formatPrice(item.product.originalPrice)}
                      </p>
                    )}
                  </div>
                  <span className="text-sm">Кол-во: {item.quantity}</span>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Card className="p-4 border-zinc-200 dark:border-zinc-800">
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-zinc-500 dark:text-zinc-400">Товары ({products.length}):</span>
            <span className="font-medium">{formatPrice(totalAmount)}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-zinc-500 dark:text-zinc-400">Доставка:</span>
            <span className="text-sm">Рассчитывается при оформлении</span>
          </div>

          <div className="border-t border-zinc-200 dark:border-zinc-700 my-1 pt-3">
            <div className="flex justify-between items-center font-bold">
              <span>Итого:</span>
              <span>{formatPrice(totalAmount)}</span>
            </div>
          </div>
        </div>
      </Card>

      <div className="space-y-3">
        <Button
          onClick={onProceedToCheckout}
          className="w-full bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 h-12"
        >
          Оформить заказ <ChevronRight className="ml-2 h-4 w-4" />
        </Button>

        <div className="flex items-center justify-center space-x-4 text-sm text-zinc-500 dark:text-zinc-400">
          <div className="flex items-center">
            <Package className="h-4 w-4 mr-1" />
            <span>Быстрая доставка</span>
          </div>
          <div className="flex items-center">
            <CreditCard className="h-4 w-4 mr-1" />
            <span>Безопасная оплата</span>
          </div>
        </div>
      </div>
    </div>
  )
}
