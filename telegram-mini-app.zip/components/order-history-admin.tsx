"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, Clock, User, Receipt, ArrowUpCircle } from "lucide-react"
import type { Order } from "@/types/order"

interface OrderHistoryAdminProps {
  orders: Order[]
  onUpdateStatus: (orderId: string, status: "pending" | "completed" | "cancelled") => void
  onRestoreProducts: (order: Order) => void
}

export function OrderHistoryAdmin({ orders, onUpdateStatus, onRestoreProducts }: OrderHistoryAdminProps) {
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null)
  const [statusFilter, setStatusFilter] = useState<string>("all")

  const toggleOrderDetails = (orderId: string) => {
    if (expandedOrderId === orderId) {
      setExpandedOrderId(null)
    } else {
      setExpandedOrderId(orderId)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">Выполнен</Badge>
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100">В обработке</Badge>
        )
      case "cancelled":
        return <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100">Отменен</Badge>
      default:
        return <Badge className="bg-zinc-100 text-zinc-800 dark:bg-zinc-800 dark:text-zinc-100">{status}</Badge>
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString() + " " + date.toLocaleTimeString()
  }

  const filteredOrders = statusFilter === "all" ? orders : orders.filter((order) => order.status === statusFilter)

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">История заказов</h2>
        <div className="flex gap-2">
          <select
            className="p-2 rounded-md border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-950"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="all">Все заказы</option>
            <option value="pending">В обработке</option>
            <option value="completed">Выполненные</option>
            <option value="cancelled">Отмененные</option>
          </select>
        </div>
      </div>

      {filteredOrders.length === 0 ? (
        <div className="text-center py-12 px-4 bg-zinc-50 dark:bg-zinc-900/50 rounded-lg border border-zinc-200 dark:border-zinc-800">
          <p className="text-zinc-500 dark:text-zinc-400">Заказы не найдены</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredOrders.map((order) => (
            <Card key={order.id} className="border-zinc-200 dark:border-zinc-800">
              <div className="p-4">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="font-medium flex items-center">
                      <Receipt className="h-5 w-5 mr-2 text-zinc-500" />
                      Заказ #{order.orderNumber}
                    </h3>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">{formatDate(order.date)}</p>
                  </div>
                  <div className="flex flex-col items-end">
                    <div className="mb-2">{getStatusBadge(order.status)}</div>
                    <div className="text-sm font-medium">{order.totalAmount.toFixed(2)} ₽</div>
                  </div>
                </div>

                <div className="border-t border-zinc-200 dark:border-zinc-700 pt-4 mb-4">
                  <h4 className="font-medium mb-2">Информация о клиенте</h4>
                  <div className="flex items-center text-sm mb-2">
                    <User className="h-4 w-4 mr-2 text-zinc-500" />
                    {order.telegramUsername ? (
                      <span>@{order.telegramUsername}</span>
                    ) : (
                      <span>Telegram ID: {order.telegramUserId}</span>
                    )}
                  </div>
                  <div className="text-sm text-zinc-500 dark:text-zinc-400">Способ оплаты: {order.paymentMethod}</div>
                </div>

                <Button variant="outline" size="sm" onClick={() => toggleOrderDetails(order.id)} className="w-full">
                  {expandedOrderId === order.id ? "Скрыть детали" : "Показать детали"}
                </Button>

                {expandedOrderId === order.id && (
                  <div className="border-t border-zinc-200 dark:border-zinc-700 pt-4 mt-4">
                    <h4 className="font-medium mb-2">Товары в заказе</h4>
                    <div className="space-y-3">
                      {order.items.map((item, index) => (
                        <div key={index} className="flex justify-between items-center">
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-zinc-200 dark:bg-zinc-800 rounded-md overflow-hidden relative flex-shrink-0 mr-3">
                              <img
                                src={item.product.image || "/placeholder.svg"}
                                alt={item.product.name}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div>
                              <div className="font-medium text-sm">{item.product.name}</div>
                              <div className="text-xs text-zinc-500 dark:text-zinc-400">
                                {item.quantity} x {item.product.price.toFixed(2)} ₽
                              </div>
                            </div>
                          </div>
                          <div className="font-medium">{(item.product.price * item.quantity).toFixed(2)} ₽</div>
                        </div>
                      ))}
                    </div>

                    <div className="border-t border-zinc-200 dark:border-zinc-700 mt-3 pt-3">
                      <div className="flex justify-between font-medium">
                        <span>Итого</span>
                        <span>{order.totalAmount.toFixed(2)} ₽</span>
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 mt-4">
                      {order.status === "pending" && (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-green-600 hover:text-green-700 hover:bg-green-50 dark:hover:bg-green-950/20"
                            onClick={() => onUpdateStatus(order.id, "completed")}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Выполнен
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/20"
                            onClick={() => onUpdateStatus(order.id, "cancelled")}
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Отменить
                          </Button>
                        </>
                      )}
                      {order.status === "completed" && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-yellow-600 hover:text-yellow-700 hover:bg-yellow-50 dark:hover:bg-yellow-950/20"
                          onClick={() => onUpdateStatus(order.id, "pending")}
                        >
                          <Clock className="h-4 w-4 mr-1" />В обработку
                        </Button>
                      )}
                      {order.status === "cancelled" && (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-yellow-600 hover:text-yellow-700 hover:bg-yellow-50 dark:hover:bg-yellow-950/20"
                            onClick={() => onUpdateStatus(order.id, "pending")}
                          >
                            <Clock className="h-4 w-4 mr-1" />В обработку
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 dark:hover:bg-blue-950/20"
                            onClick={() => onRestoreProducts(order)}
                          >
                            <ArrowUpCircle className="h-4 w-4 mr-1" />
                            Вернуть товары
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
