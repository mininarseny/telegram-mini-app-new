"use client"
import { useSettings } from "@/contexts/settings-context"
import { BellIcon as BrandTelegram, ExternalLink } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

export function Footer() {
  const { t } = useSettings()
  const [year] = useState(() => new Date().getFullYear())

  return (
    <footer className="mt-auto border-t border-zinc-200 dark:border-zinc-800 py-6 px-4">
      <div className="container mx-auto max-w-4xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Контактная информация */}
          <div>
            <h3 className="font-medium text-sm mb-2">Контакты</h3>
            <div className="space-y-2">
              <div className="flex items-center">
                <BrandTelegram className="h-5 w-5 mr-2 text-blue-500" />
                <a
                  href="https://t.me/Jericho_Services"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 dark:text-blue-400 hover:underline text-xs"
                >
                  @Jericho_Services
                </a>
              </div>
            </div>
          </div>

          {/* Информация о магазине */}
          <div>
            <h3 className="font-medium text-sm mb-2">О магазине</h3>
            <div className="space-y-2">
              <p className="text-xs text-zinc-600 dark:text-zinc-400">
                Jericho — магазин уникальной одежды и аксессуаров
              </p>
            </div>
          </div>

          {/* Документы */}
          <div>
            <h3 className="font-medium text-sm mb-2">Документы</h3>
            <div className="space-y-2">
              <div>
                <Link
                  href="/offer"
                  className="text-blue-600 dark:text-blue-400 hover:underline flex items-center text-xs"
                >
                  Публичная оферта
                  <ExternalLink className="h-3 w-3 ml-1" />
                </Link>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-zinc-200 dark:border-zinc-800 text-center text-xs text-zinc-500 dark:text-zinc-400">
          © {year} Jericho. Все права защищены.
        </div>
      </div>
    </footer>
  )
}
