"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { CheckCircle, Package, Truck, ArrowRight } from "lucide-react"
import { motion } from "framer-motion"
import { useSettings } from "@/contexts/settings-context"

interface OrderSuccessProps {
  orderNumber: string
  deliveryMethod: string
  onContinueShopping: () => void
}

export function OrderSuccess({ orderNumber, deliveryMethod, onContinueShopping }: OrderSuccessProps) {
  const { t } = useSettings()

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-md mx-auto text-center space-y-6 p-4"
    >
      <div className="flex justify-center mb-4">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 300, damping: 20 }}
        >
          <CheckCircle className="h-20 w-20 text-green-500" />
        </motion.div>
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
        <h2 className="text-2xl font-bold mb-2">Заказ успешно оформлен!</h2>
        <p className="text-zinc-500 dark:text-zinc-400">
          Спасибо за ваш заказ. Мы отправим вам уведомление, когда он будет отправлен.
        </p>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
        <Card className="p-4 border-zinc-200 dark:border-zinc-800">
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-zinc-500 dark:text-zinc-400">Номер заказа:</span>
              <span className="font-bold">{orderNumber}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-zinc-500 dark:text-zinc-400">Способ доставки:</span>
              <span className="flex items-center">
                {deliveryMethod === "russian-post" ? (
                  <Truck className="h-4 w-4 mr-1" />
                ) : (
                  <Package className="h-4 w-4 mr-1" />
                )}
                {deliveryMethod === "russian-post"
                  ? "Почта России"
                  : deliveryMethod === "boxberry"
                    ? "Boxberry"
                    : "Самовывоз"}
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-zinc-500 dark:text-zinc-400">Статус оплаты:</span>
              <span className="text-green-600 dark:text-green-400 font-medium">Оплачено</span>
            </div>
          </div>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-md p-4 text-blue-800 dark:text-blue-200"
      >
        <p className="text-sm">
          Мы отправили информацию о заказе на вашу электронную почту. Вы также можете отслеживать статус заказа в
          разделе "Мои заказы".
        </p>
      </motion.div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1 }}>
        <Button
          onClick={onContinueShopping}
          className="bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
        >
          Продолжить покупки <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </motion.div>
    </motion.div>
  )
}
