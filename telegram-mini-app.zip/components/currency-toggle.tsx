"use client"

import { Button } from "@/components/ui/button"
import { useSettings } from "@/contexts/settings-context"
import { DollarSign, Coins } from "lucide-react"

export function CurrencyToggle() {
  const { currency, toggleCurrency } = useSettings()

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={toggleCurrency}
      className="rounded-full"
      title={currency === "RUB" ? "Switch to USD" : "Switch to RUB"}
    >
      {currency === "RUB" ? <DollarSign className="h-5 w-5" /> : <Coins className="h-5 w-5" />}
    </Button>
  )
}
