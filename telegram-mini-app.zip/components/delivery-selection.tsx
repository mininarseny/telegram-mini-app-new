"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Truck, Package } from "lucide-react"
import { useSettings } from "@/contexts/settings-context"

type DeliveryMethod = "russian-post" | "boxberry"

interface DeliveryOption {
  id: DeliveryMethod
  name: string
  description: string
  icon: React.ReactNode
  price: number
}

interface DeliverySelectionProps {
  onSelect: (method: DeliveryMethod, price: number) => void
  onCancel: () => void
}

export function DeliverySelection({ onSelect, onCancel }: DeliverySelectionProps) {
  const { formatPrice, t } = useSettings()
  const [selectedDelivery, setSelectedDelivery] = useState<DeliveryMethod | null>(null)

  // Опции доставки
  const deliveryOptions: DeliveryOption[] = [
    {
      id: "russian-post",
      name: t("delivery.russian_post"),
      description: t("delivery.russian_post_desc"),
      icon: <Truck className="h-5 w-5" />,
      price: 350,
    },
    {
      id: "boxberry",
      name: t("delivery.boxberry"),
      description: t("delivery.boxberry_desc"),
      icon: <Package className="h-5 w-5" />,
      price: 300,
    },
  ]

  const handleConfirm = () => {
    if (selectedDelivery) {
      const option = deliveryOptions.find((opt) => opt.id === selectedDelivery)
      if (option) {
        onSelect(selectedDelivery, option.price)
      }
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-4 max-w-md mx-auto"
    >
      <h2 className="text-xl font-bold text-center mb-4">{t("delivery.title")}</h2>

      <Card className="p-4 border-zinc-200 dark:border-zinc-800">
        <RadioGroup
          value={selectedDelivery || ""}
          onValueChange={(value) => setSelectedDelivery(value as DeliveryMethod)}
          className="space-y-2"
        >
          {deliveryOptions.map((option) => (
            <div
              key={option.id}
              className="flex items-start space-x-2 border border-zinc-200 dark:border-zinc-800 rounded-md p-3 cursor-pointer hover:bg-zinc-50 dark:hover:bg-zinc-900/50"
              onClick={() => setSelectedDelivery(option.id)}
            >
              <RadioGroupItem value={option.id} id={`delivery-${option.id}`} className="mt-1" />
              <div className="flex-1">
                <Label htmlFor={`delivery-${option.id}`} className="font-medium cursor-pointer flex items-center">
                  <span className="mr-2">{option.icon}</span>
                  {option.name}
                </Label>
                <p className="text-sm text-zinc-500 dark:text-zinc-400">{option.description}</p>
                <div className="flex justify-between mt-1">
                  <span className="text-sm text-zinc-600 dark:text-zinc-300">{formatPrice(option.price)}</span>
                </div>
              </div>
            </div>
          ))}
        </RadioGroup>
      </Card>

      <div className="flex justify-between pt-2">
        <Button variant="outline" onClick={onCancel}>
          {t("delivery.cancel")}
        </Button>
        <Button
          onClick={handleConfirm}
          disabled={!selectedDelivery}
          className="bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
        >
          {t("delivery.confirm")}
        </Button>
      </div>
    </motion.div>
  )
}
