"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useSettings } from "@/contexts/settings-context"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ChevronDown, ChevronUp, ShoppingBag, Calendar, Receipt } from "lucide-react"
import type { Order } from "@/types/order"

interface OrderHistoryProps {
  orders: Order[]
  onBackToProducts: () => void
}

export function OrderHistory({ orders, onBackToProducts }: OrderHistoryProps) {
  const { t, formatPrice } = useSettings()
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null)

  const toggleOrderDetails = (orderId: string) => {
    if (expandedOrderId === orderId) {
      setExpandedOrderId(null)
    } else {
      setExpandedOrderId(orderId)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
            {t("orders.status_completed")}
          </Badge>
        )
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100">
            {t("orders.status_pending")}
          </Badge>
        )
      case "cancelled":
        return (
          <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100">
            {t("orders.status_cancelled")}
          </Badge>
        )
      default:
        return <Badge className="bg-zinc-100 text-zinc-800 dark:bg-zinc-800 dark:text-zinc-100">{status}</Badge>
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString()
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-4 space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold flex items-center">
          <ShoppingBag className="mr-2 h-5 w-5" />
          {t("orders.title")}
        </h2>
        <Button variant="outline" size="sm" onClick={onBackToProducts}>
          {t("orders.back")}
        </Button>
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-12 px-4 bg-zinc-50 dark:bg-zinc-900/50 rounded-lg border border-zinc-200 dark:border-zinc-800">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-zinc-100 dark:bg-zinc-800 mb-4">
            <ShoppingBag className="h-8 w-8 text-zinc-500 dark:text-zinc-400" />
          </div>
          <h3 className="text-lg font-medium mb-2">{t("orders.empty")}</h3>
          <p className="text-zinc-500 dark:text-zinc-400 mb-6">{t("orders.empty_desc")}</p>
          <Button
            onClick={onBackToProducts}
            className="bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
          >
            {t("app.continue_shopping")}
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => (
            <Card key={order.id} className="border-zinc-200 dark:border-zinc-800 overflow-hidden">
              <div className="p-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Receipt className="h-5 w-5 mr-2 text-zinc-500" />
                    <span className="font-medium">
                      {t("orders.order")} #{order.orderNumber}
                    </span>
                  </div>
                  {getStatusBadge(order.status)}
                </div>

                <div className="flex justify-between items-center mt-2 text-sm">
                  <div className="flex items-center text-zinc-500 dark:text-zinc-400">
                    <Calendar className="h-4 w-4 mr-1" />
                    {formatDate(order.date)}
                  </div>
                  <div className="font-medium">{formatPrice(order.totalAmount)}</div>
                </div>

                <div className="flex justify-between items-center mt-2 text-sm">
                  <div className="text-zinc-500 dark:text-zinc-400">
                    {t("orders.items")}: {order.items.reduce((sum, item) => sum + item.quantity, 0)}
                  </div>
                  <div className="text-zinc-500 dark:text-zinc-400">
                    {t("orders.payment_method")}: {order.paymentMethod}
                  </div>
                </div>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleOrderDetails(order.id)}
                  className="w-full mt-2 flex items-center justify-center"
                >
                  {expandedOrderId === order.id ? (
                    <>
                      {t("orders.hide_details")}
                      <ChevronUp className="ml-1 h-4 w-4" />
                    </>
                  ) : (
                    <>
                      {t("orders.show_details")}
                      <ChevronDown className="ml-1 h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>

              {expandedOrderId === order.id && (
                <div className="border-t border-zinc-200 dark:border-zinc-800 p-4 bg-zinc-50 dark:bg-zinc-900/50">
                  <h4 className="font-medium mb-2">{t("orders.order_items")}</h4>
                  <div className="space-y-3">
                    {order.items.map((item, index) => (
                      <div key={index} className="flex justify-between items-center">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-zinc-200 dark:bg-zinc-800 rounded-md overflow-hidden relative flex-shrink-0 mr-3">
                            <img
                              src={item.product.image || "/placeholder.svg"}
                              alt={item.product.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div>
                            <div className="font-medium text-sm">{item.product.name}</div>
                            <div className="text-xs text-zinc-500 dark:text-zinc-400">
                              {item.quantity} x {formatPrice(item.product.price)}
                            </div>
                          </div>
                        </div>
                        <div className="font-medium">{formatPrice(item.product.price * item.quantity)}</div>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-zinc-200 dark:border-zinc-700 mt-3 pt-3">
                    <div className="flex justify-between font-medium">
                      <span>{t("orders.total")}</span>
                      <span>{formatPrice(order.totalAmount)}</span>
                    </div>
                  </div>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </motion.div>
  )
}
