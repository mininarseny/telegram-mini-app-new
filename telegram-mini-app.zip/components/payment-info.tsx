"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, CreditCard, Loader2, Check, AlertCircle } from "lucide-react"
import { motion } from "framer-motion"
import { useState } from "react"
import { useSettings } from "@/contexts/settings-context"

interface PaymentInfoProps {
  productName: string
  price: number
  productLink?: string
  onBackToShopping: () => void
  onOrderComplete: (paymentMethod: string) => void
  orderNumber: string
}

export function PaymentInfo({
  productName,
  price,
  productLink,
  onBackToShopping,
  onOrderComplete,
  orderNumber,
}: PaymentInfoProps) {
  const { formatPrice, t } = useSettings()
  const [isLoading, setIsLoading] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState<"pending" | "processing" | "success" | "error">("pending")
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  // Имитация процесса оплаты через ЮKassa
  const handlePayment = () => {
    setIsLoading(true)
    setPaymentStatus("processing")

    // Имитируем запрос к API ЮKassa
    setTimeout(() => {
      setIsLoading(false)
      setPaymentStatus("success")

      // После успешной оплаты
      setTimeout(() => {
        onOrderComplete("yookassa")
      }, 2000)
    }, 3000)
  }

  // Обработчик отмены оплаты
  const handleCancel = () => {
    if (paymentStatus === "processing") {
      setErrorMessage("Оплата была отменена. Попробуйте снова или выберите другой способ оплаты.")
      setPaymentStatus("error")
      setIsLoading(false)
    } else {
      onBackToShopping()
    }
  }

  // Обработчик повторной попытки оплаты
  const handleRetry = () => {
    setErrorMessage(null)
    setPaymentStatus("pending")
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-4 max-w-md mx-auto"
    >
      <div className="text-center">
        <h2 className="text-xl font-bold mb-2">{t("payment.title")}</h2>
        <p className="text-zinc-500 dark:text-zinc-400">{t("payment.desc").replace("{price}", formatPrice(price))}</p>
      </div>

      {/* Номер заказа */}
      <Card className="p-4 border-zinc-200 dark:border-zinc-800 overflow-hidden">
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-medium">{t("payment.order_number")}</h3>
        </div>
        <div className="bg-zinc-100 dark:bg-zinc-800 p-3 rounded-md text-center">
          <span className="font-mono text-lg tracking-wider">{orderNumber}</span>
        </div>
      </Card>

      {/* Блок оплаты ЮKassa */}
      <Card className="p-4 border-zinc-200 dark:border-zinc-800 overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium">Оплата через ЮKassa</h3>
          <img src="/placeholder.svg?height=30&width=120" alt="ЮKassa" className="h-8" />
        </div>

        {paymentStatus === "pending" && (
          <div className="space-y-4">
            <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-md p-3 text-blue-800 dark:text-blue-200">
              <p className="text-sm">
                Нажмите кнопку "Оплатить" для перехода на страницу безопасной оплаты ЮKassa. После успешной оплаты вы
                будете автоматически перенаправлены обратно.
              </p>
            </div>

            <div className="flex items-center justify-center space-x-2 my-4">
              <img src="/placeholder.svg?height=30&width=40" alt="Visa" className="h-6" />
              <img src="/placeholder.svg?height=30&width=40" alt="MasterCard" className="h-6" />
              <img src="/placeholder.svg?height=30&width=40" alt="Мир" className="h-6" />
            </div>

            <Button
              onClick={handlePayment}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              disabled={isLoading}
            >
              Оплатить {formatPrice(price)} <CreditCard className="ml-2 h-4 w-4" />
            </Button>
          </div>
        )}

        {paymentStatus === "processing" && (
          <div className="text-center py-6">
            <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4 text-blue-600 dark:text-blue-400" />
            <h3 className="text-lg font-medium mb-2">Обработка платежа</h3>
            <p className="text-zinc-500 dark:text-zinc-400 mb-4">
              Пожалуйста, не закрывайте это окно до завершения операции
            </p>
          </div>
        )}

        {paymentStatus === "success" && (
          <div className="text-center py-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 dark:bg-green-900 mb-4">
              <Check className="h-8 w-8 text-green-600 dark:text-green-300" />
            </div>
            <h3 className="text-lg font-medium mb-2">Оплата прошла успешно!</h3>
            <p className="text-zinc-500 dark:text-zinc-400">
              Ваш заказ #{orderNumber} успешно оплачен и принят в обработку
            </p>
          </div>
        )}

        {paymentStatus === "error" && (
          <div className="text-center py-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-100 dark:bg-red-900 mb-4">
              <AlertCircle className="h-8 w-8 text-red-600 dark:text-red-300" />
            </div>
            <h3 className="text-lg font-medium mb-2">Ошибка оплаты</h3>
            <p className="text-zinc-500 dark:text-zinc-400 mb-4">{errorMessage}</p>
            <Button onClick={handleRetry} className="bg-zinc-900 hover:bg-zinc-800 text-white">
              Попробовать снова
            </Button>
          </div>
        )}
      </Card>

      {/* Информация о товаре */}
      <Card className="p-4 border-zinc-200 dark:border-zinc-800 overflow-hidden">
        <h3 className="font-medium mb-3">Информация о заказе</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-zinc-500 dark:text-zinc-400">{t("payment.item")}:</span>
            <span className="font-medium">{productName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-zinc-500 dark:text-zinc-400">{t("payment.amount")}:</span>
            <span className="font-medium">{formatPrice(price)}</span>
          </div>
        </div>
      </Card>

      {/* Кнопка отмены */}
      {paymentStatus !== "success" && (
        <Button variant="outline" onClick={handleCancel} className="w-full">
          <ArrowLeft className="mr-2 h-4 w-4" />
          {paymentStatus === "processing" ? "Отменить оплату" : t("payment.back_to_shop")}
        </Button>
      )}
    </motion.div>
  )
}
