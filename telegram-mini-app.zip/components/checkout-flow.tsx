"use client"

import type React from "react"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ChevronRight, MapPin, CreditCard, Package, Truck, Check, ArrowLeft, Building } from "lucide-react"
import { useSettings } from "@/contexts/settings-context"
import type { Product } from "@/types/product"

// Шаги оформления заказа
type CheckoutStep = "delivery" | "payment" | "confirmation"

// Способы доставки
type DeliveryMethod = "russian-post" | "boxberry" | "pickup"

// Способы оплаты
type PaymentMethod = "yookassa-card" | "yookassa-sbp" | "yookassa-qr"

interface DeliveryOption {
  id: DeliveryMethod
  name: string
  description: string
  icon: React.ReactNode
  price: number
  estimatedDays: string
}

interface PaymentOption {
  id: PaymentMethod
  name: string
  description: string
  icon: React.ReactNode
}

interface CheckoutFlowProps {
  products: Array<{ product: Product; quantity: number }>
  totalAmount: number
  onComplete: (orderData: any) => void
  onCancel: () => void
}

export function CheckoutFlow({ products, totalAmount, onComplete, onCancel }: CheckoutFlowProps) {
  const { formatPrice, t } = useSettings()
  const [currentStep, setCurrentStep] = useState<CheckoutStep>("delivery")
  const [selectedDelivery, setSelectedDelivery] = useState<DeliveryMethod | null>(null)
  const [selectedPayment, setSelectedPayment] = useState<PaymentMethod | null>(null)

  // Данные формы доставки
  const [deliveryData, setDeliveryData] = useState({
    fullName: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    postalCode: "",
    comment: "",
  })

  // Опции доставки
  const deliveryOptions: DeliveryOption[] = [
    {
      id: "russian-post",
      name: "Почта России",
      description: "Доставка в любую точку России",
      icon: <Truck className="h-5 w-5" />,
      price: 350,
      estimatedDays: "5-10 дней",
    },
    {
      id: "boxberry",
      name: "Boxberry",
      description: "Доставка до пункта выдачи",
      icon: <Package className="h-5 w-5" />,
      price: 300,
      estimatedDays: "3-7 дней",
    },
    {
      id: "pickup",
      name: "Самовывоз",
      description: "Из нашего магазина",
      icon: <Building className="h-5 w-5" />,
      price: 0,
      estimatedDays: "1-2 дня",
    },
  ]

  // Опции оплаты
  const paymentOptions: PaymentOption[] = [
    {
      id: "yookassa-card",
      name: "Банковская карта",
      description: "Visa, MasterCard, МИР",
      icon: <CreditCard className="h-5 w-5" />,
    },
    {
      id: "yookassa-sbp",
      name: "Система быстрых платежей",
      description: "Оплата по QR-коду через СБП",
      icon: <CreditCard className="h-5 w-5" />,
    },
    {
      id: "yookassa-qr",
      name: "Оплата по QR-коду",
      description: "Сбербанк, Тинькофф, Альфа-Банк и др.",
      icon: <CreditCard className="h-5 w-5" />,
    },
  ]

  // Обработчик изменения полей формы
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setDeliveryData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // Обработчик перехода к следующему шагу
  const handleNextStep = () => {
    if (currentStep === "delivery") {
      setCurrentStep("payment")
    } else if (currentStep === "payment") {
      setCurrentStep("confirmation")
    }
  }

  // Обработчик возврата к предыдущему шагу
  const handlePrevStep = () => {
    if (currentStep === "payment") {
      setCurrentStep("delivery")
    } else if (currentStep === "confirmation") {
      setCurrentStep("payment")
    }
  }

  // Обработчик завершения оформления заказа
  const handleCompleteOrder = () => {
    const selectedDeliveryOption = deliveryOptions.find((option) => option.id === selectedDelivery)

    const orderData = {
      delivery: {
        method: selectedDelivery,
        price: selectedDeliveryOption?.price || 0,
        ...deliveryData,
      },
      payment: {
        method: selectedPayment,
      },
      products,
      totalAmount,
      deliveryAmount: selectedDeliveryOption?.price || 0,
      finalAmount: totalAmount + (selectedDeliveryOption?.price || 0),
    }

    onComplete(orderData)
  }

  // Проверка возможности перехода к следующему шагу
  const canProceedToPayment = () => {
    if (!selectedDelivery) return false

    // Для самовывоза нужны только имя и телефон
    if (selectedDelivery === "pickup") {
      return deliveryData.fullName.trim() !== "" && deliveryData.phone.trim() !== ""
    }

    // Для доставки нужны все поля кроме комментария
    return (
      deliveryData.fullName.trim() !== "" &&
      deliveryData.phone.trim() !== "" &&
      deliveryData.email.trim() !== "" &&
      deliveryData.address.trim() !== "" &&
      deliveryData.city.trim() !== "" &&
      deliveryData.postalCode.trim() !== ""
    )
  }

  // Получение выбранного способа доставки
  const getSelectedDeliveryOption = () => {
    return deliveryOptions.find((option) => option.id === selectedDelivery)
  }

  // Рендер шага выбора доставки
  const renderDeliveryStep = () => {
    const selectedOption = getSelectedDeliveryOption()

    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="space-y-4"
      >
        <h2 className="text-xl font-bold text-center mb-4">Выберите способ доставки</h2>

        <Card className="p-4 border-zinc-200 dark:border-zinc-800">
          <RadioGroup
            value={selectedDelivery || ""}
            onValueChange={(value) => setSelectedDelivery(value as DeliveryMethod)}
            className="space-y-2"
          >
            {deliveryOptions.map((option) => (
              <div
                key={option.id}
                className="flex items-start space-x-2 border border-zinc-200 dark:border-zinc-800 rounded-md p-3 cursor-pointer hover:bg-zinc-50 dark:hover:bg-zinc-900/50"
                onClick={() => setSelectedDelivery(option.id)}
              >
                <RadioGroupItem value={option.id} id={`delivery-${option.id}`} className="mt-1" />
                <div className="flex-1">
                  <Label htmlFor={`delivery-${option.id}`} className="font-medium cursor-pointer flex items-center">
                    <span className="mr-2">{option.icon}</span>
                    {option.name}
                  </Label>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400">{option.description}</p>
                  <div className="flex justify-between mt-1">
                    <span className="text-sm text-zinc-600 dark:text-zinc-300">
                      {option.price > 0 ? formatPrice(option.price) : "Бесплатно"}
                    </span>
                    <span className="text-sm text-zinc-600 dark:text-zinc-300">{option.estimatedDays}</span>
                  </div>
                </div>
              </div>
            ))}
          </RadioGroup>
        </Card>

        {selectedDelivery && (
          <Card className="p-4 border-zinc-200 dark:border-zinc-800">
            <h3 className="font-medium mb-3 flex items-center">
              <MapPin className="h-5 w-5 mr-2 text-zinc-500" />
              Данные для доставки
            </h3>

            <div className="space-y-3">
              <div>
                <Label htmlFor="fullName">ФИО получателя</Label>
                <Input
                  id="fullName"
                  name="fullName"
                  value={deliveryData.fullName}
                  onChange={handleInputChange}
                  placeholder="Иванов Иван Иванович"
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="phone">Телефон</Label>
                <Input
                  id="phone"
                  name="phone"
                  value={deliveryData.phone}
                  onChange={handleInputChange}
                  placeholder="+7 (999) 123-45-67"
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={deliveryData.email}
                  onChange={handleInputChange}
                  placeholder="example@mail.ru"
                  className="mt-1"
                />
              </div>

              {selectedDelivery !== "pickup" && (
                <>
                  <div>
                    <Label htmlFor="city">Город</Label>
                    <Input
                      id="city"
                      name="city"
                      value={deliveryData.city}
                      onChange={handleInputChange}
                      placeholder="Москва"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="address">Адрес</Label>
                    <Input
                      id="address"
                      name="address"
                      value={deliveryData.address}
                      onChange={handleInputChange}
                      placeholder="ул. Примерная, д. 1, кв. 1"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="postalCode">Индекс</Label>
                    <Input
                      id="postalCode"
                      name="postalCode"
                      value={deliveryData.postalCode}
                      onChange={handleInputChange}
                      placeholder="123456"
                      className="mt-1"
                    />
                  </div>
                </>
              )}

              <div>
                <Label htmlFor="comment">Комментарий к заказу (необязательно)</Label>
                <Textarea
                  id="comment"
                  name="comment"
                  value={deliveryData.comment}
                  onChange={handleInputChange}
                  placeholder="Дополнительная информация по заказу"
                  className="mt-1"
                />
              </div>
            </div>
          </Card>
        )}

        <div className="flex justify-between pt-2">
          <Button variant="outline" onClick={onCancel}>
            Отмена
          </Button>
          <Button
            onClick={handleNextStep}
            disabled={!canProceedToPayment()}
            className="bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
          >
            Перейти к оплате <ChevronRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </motion.div>
    )
  }

  // Рендер шага выбора оплаты
  const renderPaymentStep = () => {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="space-y-4"
      >
        <h2 className="text-xl font-bold text-center mb-4">Выберите способ оплаты</h2>

        <Card className="p-4 border-zinc-200 dark:border-zinc-800">
          <div className="flex items-center mb-3">
            <img src="/placeholder.svg?height=30&width=120" alt="ЮKassa" className="h-8" />
            <span className="ml-2 text-sm text-zinc-500">Безопасная оплата</span>
          </div>

          <RadioGroup
            value={selectedPayment || ""}
            onValueChange={(value) => setSelectedPayment(value as PaymentMethod)}
            className="space-y-2"
          >
            {paymentOptions.map((option) => (
              <div
                key={option.id}
                className="flex items-start space-x-2 border border-zinc-200 dark:border-zinc-800 rounded-md p-3 cursor-pointer hover:bg-zinc-50 dark:hover:bg-zinc-900/50"
                onClick={() => setSelectedPayment(option.id)}
              >
                <RadioGroupItem value={option.id} id={`payment-${option.id}`} className="mt-1" />
                <div className="flex-1">
                  <Label htmlFor={`payment-${option.id}`} className="font-medium cursor-pointer flex items-center">
                    <span className="mr-2">{option.icon}</span>
                    {option.name}
                  </Label>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400">{option.description}</p>
                </div>
              </div>
            ))}
          </RadioGroup>
        </Card>

        <Card className="p-4 border-zinc-200 dark:border-zinc-800">
          <h3 className="font-medium mb-3">Информация о заказе</h3>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-zinc-500 dark:text-zinc-400">Товары ({products.length}):</span>
              <span>{formatPrice(totalAmount)}</span>
            </div>

            <div className="flex justify-between text-sm">
              <span className="text-zinc-500 dark:text-zinc-400">Доставка:</span>
              <span>
                {getSelectedDeliveryOption()?.price
                  ? formatPrice(getSelectedDeliveryOption()?.price || 0)
                  : "Бесплатно"}
              </span>
            </div>

            <div className="border-t border-zinc-200 dark:border-zinc-700 my-2 pt-2">
              <div className="flex justify-between font-bold">
                <span>Итого:</span>
                <span>{formatPrice(totalAmount + (getSelectedDeliveryOption()?.price || 0))}</span>
              </div>
            </div>
          </div>
        </Card>

        <div className="flex justify-between pt-2">
          <Button variant="outline" onClick={handlePrevStep}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Назад
          </Button>
          <Button
            onClick={handleNextStep}
            disabled={!selectedPayment}
            className="bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
          >
            Подтвердить заказ <ChevronRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </motion.div>
    )
  }

  // Рендер шага подтверждения заказа
  const renderConfirmationStep = () => {
    const selectedDeliveryOption = getSelectedDeliveryOption()
    const selectedPaymentOption = paymentOptions.find((option) => option.id === selectedPayment)

    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="space-y-4"
      >
        <div className="text-center mb-4">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 dark:bg-green-900 mb-4">
            <Check className="h-8 w-8 text-green-600 dark:text-green-300" />
          </div>
          <h2 className="text-xl font-bold">Подтверждение заказа</h2>
          <p className="text-zinc-500 dark:text-zinc-400 mt-1">Проверьте данные перед оплатой</p>
        </div>

        <Card className="p-4 border-zinc-200 dark:border-zinc-800">
          <h3 className="font-medium mb-3">Информация о доставке</h3>

          <div className="space-y-2">
            <div className="flex items-center">
              <span className="text-zinc-500 dark:text-zinc-400 w-1/3">Способ доставки:</span>
              <span className="font-medium flex items-center">
                <span className="mr-2">{selectedDeliveryOption?.icon}</span>
                {selectedDeliveryOption?.name}
              </span>
            </div>

            <div className="flex">
              <span className="text-zinc-500 dark:text-zinc-400 w-1/3">Получатель:</span>
              <span>{deliveryData.fullName}</span>
            </div>

            <div className="flex">
              <span className="text-zinc-500 dark:text-zinc-400 w-1/3">Телефон:</span>
              <span>{deliveryData.phone}</span>
            </div>

            {selectedDelivery !== "pickup" && (
              <>
                <div className="flex">
                  <span className="text-zinc-500 dark:text-zinc-400 w-1/3">Адрес:</span>
                  <span>
                    {deliveryData.city}, {deliveryData.address}, {deliveryData.postalCode}
                  </span>
                </div>
              </>
            )}

            {deliveryData.comment && (
              <div className="flex">
                <span className="text-zinc-500 dark:text-zinc-400 w-1/3">Комментарий:</span>
                <span>{deliveryData.comment}</span>
              </div>
            )}
          </div>
        </Card>

        <Card className="p-4 border-zinc-200 dark:border-zinc-800">
          <h3 className="font-medium mb-3">Способ оплаты</h3>

          <div className="flex items-center">
            <span className="mr-2">{selectedPaymentOption?.icon}</span>
            <div>
              <div className="font-medium">{selectedPaymentOption?.name}</div>
              <div className="text-sm text-zinc-500 dark:text-zinc-400">{selectedPaymentOption?.description}</div>
            </div>
          </div>
        </Card>

        <Card className="p-4 border-zinc-200 dark:border-zinc-800">
          <h3 className="font-medium mb-3">Итоговая сумма</h3>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-zinc-500 dark:text-zinc-400">Товары ({products.length}):</span>
              <span>{formatPrice(totalAmount)}</span>
            </div>

            <div className="flex justify-between text-sm">
              <span className="text-zinc-500 dark:text-zinc-400">Доставка:</span>
              <span>{selectedDeliveryOption?.price ? formatPrice(selectedDeliveryOption.price) : "Бесплатно"}</span>
            </div>

            <div className="border-t border-zinc-200 dark:border-zinc-700 my-2 pt-2">
              <div className="flex justify-between font-bold">
                <span>Итого к оплате:</span>
                <span>{formatPrice(totalAmount + (selectedDeliveryOption?.price || 0))}</span>
              </div>
            </div>
          </div>
        </Card>

        <div className="flex justify-between pt-2">
          <Button variant="outline" onClick={handlePrevStep}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Назад
          </Button>
          <Button onClick={handleCompleteOrder} className="bg-green-600 hover:bg-green-700 text-white">
            Оплатить заказ <CreditCard className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </motion.div>
    )
  }

  return (
    <div className="max-w-md mx-auto">
      <AnimatePresence mode="wait">
        {currentStep === "delivery" && renderDeliveryStep()}
        {currentStep === "payment" && renderPaymentStep()}
        {currentStep === "confirmation" && renderConfirmationStep()}
      </AnimatePresence>
    </div>
  )
}
