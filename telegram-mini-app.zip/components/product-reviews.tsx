"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useSettings } from "@/contexts/settings-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Star, MessageSquare, Plus, User } from "lucide-react"
import type { Review } from "@/types/review"

interface ProductReviewsProps {
  productId: number
  initialReviews: Review[]
  onAddReview: (review: Omit<Review, "id" | "date">) => void
}

export function ProductReviews({ productId, initialReviews, onAddReview }: ProductReviewsProps) {
  const { t } = useSettings()
  const [reviews, setReviews] = useState<Review[]>(initialReviews)
  const [isAddingReview, setIsAddingReview] = useState(false)
  const [userName, setUserName] = useState("")
  const [rating, setRating] = useState(5)
  const [comment, setComment] = useState("")

  const handleAddReview = () => {
    if (!userName.trim() || !comment.trim()) {
      return
    }

    const newReview = {
      productId,
      userName,
      rating,
      comment,
    }

    onAddReview(newReview)

    // Optimistically update UI
    const fakeId = Math.floor(Math.random() * 10000)
    setReviews([
      ...reviews,
      {
        id: fakeId,
        productId,
        userName,
        rating,
        comment,
        date: new Date().toISOString(),
      },
    ])

    // Reset form
    setUserName("")
    setRating(5)
    setComment("")
    setIsAddingReview(false)
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString()
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-medium flex items-center">
          <MessageSquare className="h-5 w-5 mr-2 text-zinc-500" />
          {t("reviews.title")} ({reviews.length})
        </h3>
        {!isAddingReview && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsAddingReview(true)}
            className="flex items-center gap-1"
          >
            <Plus className="h-4 w-4" />
            {t("reviews.add")}
          </Button>
        )}
      </div>

      {isAddingReview && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="border border-zinc-200 dark:border-zinc-800 rounded-md p-4 space-y-3"
        >
          <h4 className="font-medium">{t("reviews.write")}</h4>
          <div className="space-y-2">
            <label className="text-sm text-zinc-500 dark:text-zinc-400">{t("reviews.name")}</label>
            <Input
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              placeholder={t("reviews.name_placeholder")}
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-zinc-500 dark:text-zinc-400">{t("reviews.rating")}</label>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button key={star} type="button" onClick={() => setRating(star)} className="focus:outline-none">
                  <Star
                    className={`h-6 w-6 ${
                      star <= rating ? "fill-yellow-400 text-yellow-400" : "text-zinc-300 dark:text-zinc-600"
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm text-zinc-500 dark:text-zinc-400">{t("reviews.comment")}</label>
            <Textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder={t("reviews.comment_placeholder")}
              rows={3}
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={() => setIsAddingReview(false)}>
              {t("reviews.cancel")}
            </Button>
            <Button
              size="sm"
              onClick={handleAddReview}
              disabled={!userName.trim() || !comment.trim()}
              className="bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900"
            >
              {t("reviews.submit")}
            </Button>
          </div>
        </motion.div>
      )}

      {reviews.length === 0 ? (
        <div className="text-center py-6 px-4 bg-zinc-50 dark:bg-zinc-900/50 rounded-md border border-zinc-200 dark:border-zinc-800">
          <p className="text-zinc-500 dark:text-zinc-400">{t("reviews.no_reviews")}</p>
        </div>
      ) : (
        <div className="space-y-4">
          {reviews.map((review) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="border border-zinc-200 dark:border-zinc-800 rounded-md p-4"
            >
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <div className="bg-zinc-100 dark:bg-zinc-800 rounded-full w-8 h-8 flex items-center justify-center">
                    <User className="h-4 w-4 text-zinc-500 dark:text-zinc-400" />
                  </div>
                  <div>
                    <div className="font-medium">{review.userName}</div>
                    <div className="text-xs text-zinc-500 dark:text-zinc-400">{formatDate(review.date)}</div>
                  </div>
                </div>
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`h-4 w-4 ${
                        star <= review.rating ? "fill-yellow-400 text-yellow-400" : "text-zinc-300 dark:text-zinc-600"
                      }`}
                    />
                  ))}
                </div>
              </div>
              <p className="text-sm text-zinc-600 dark:text-zinc-300 whitespace-pre-line">{review.comment}</p>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
