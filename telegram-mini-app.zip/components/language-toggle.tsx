"use client"

import { Button } from "@/components/ui/button"
import { useSettings } from "@/contexts/settings-context"
import { Languages } from "lucide-react"

export function LanguageToggle() {
  const { language, toggleLanguage } = useSettings()

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={toggleLanguage}
      className="rounded-full"
      title={language === "ru" ? "Switch to English" : "Переключить на русский"}
    >
      <Languages className="h-5 w-5" />
      <span className="absolute -bottom-1 -right-1 text-[10px] font-bold bg-zinc-200 dark:bg-zinc-800 rounded-full w-4 h-4 flex items-center justify-center">
        {language === "ru" ? "EN" : "RU"}
      </span>
    </Button>
  )
}
