"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { BellIcon as BrandTelegram } from "lucide-react"
import { useSettings } from "@/contexts/settings-context"

interface AuthScreenProps {
  onLogin: () => void
}

export function AuthScreen({ onLogin }: AuthScreenProps) {
  const { t } = useSettings()

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="flex flex-col items-center justify-center min-h-[80vh] p-4 text-center"
    >
      <div className="w-24 h-24 bg-blue-500 rounded-full flex items-center justify-center mb-6">
        <BrandTelegram className="h-12 w-12 text-white" />
      </div>

      <h1 className="text-2xl font-bold mb-2">Jericho</h1>
      <p className="text-zinc-500 dark:text-zinc-400 mb-8 max-w-md">
        Для использования приложения необходимо авторизоваться через Telegram
      </p>

      <div className="space-y-4 w-full max-w-xs">
        <Button
          onClick={onLogin}
          className="w-full bg-blue-500 hover:bg-blue-600 text-white flex items-center justify-center gap-2"
          size="lg"
        >
          <BrandTelegram className="h-5 w-5" />
          Войти через Telegram
        </Button>

        {/* Добавляем кнопку пропуска авторизации */}
        <Button
          onClick={onLogin}
          className="w-full bg-zinc-200 hover:bg-zinc-300 text-zinc-800 dark:bg-zinc-800 dark:hover:bg-zinc-700 dark:text-zinc-200"
          size="lg"
        >
          Пропустить авторизацию (тест)
        </Button>

        <div className="text-sm text-zinc-500 dark:text-zinc-400 mt-4">
          <p>Это приложение работает только внутри Telegram.</p>
          <p className="mt-2">Пожалуйста, откройте ссылку в приложении Telegram.</p>
        </div>
      </div>
    </motion.div>
  )
}
