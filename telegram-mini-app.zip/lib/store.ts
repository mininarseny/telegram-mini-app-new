import type { Product } from "@/types/product"

// Начальные данные для товаров
const initialProducts: Product[] = [
  {
    id: 1,
    name: "Vintage Denim Jacket",
    price: 89.99,
    originalPrice: 129.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Authentic vintage denim jacket from the 90s. One-of-a-kind piece with unique distressing and fading.",
    category: "Outerwear",
    isNew: true,
    isAvailable: true,
    productLink: "https://www.avito.ru/item/12345",
    size: "M",
    measurements: [
      { name: "Плечи", value: "45 см" },
      { name: "Грудь", value: "52 см" },
      { name: "Длина", value: "65 см" },
      { name: "Рукав", value: "60 см" },
    ],
  },
  {
    id: 2,
    name: "Hand-painted T-Shirt",
    price: 59.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Custom hand-painted t-shirt with original artwork. Each piece is unique and signed by the artist.",
    category: "T-Shirts",
    isNew: true,
    isAvailable: true,
    productLink: "https://www.avito.ru/item/23456",
    size: "L",
    measurements: [
      { name: "Плечи", value: "47 см" },
      { name: "Грудь", value: "54 см" },
      { name: "Длина", value: "70 см" },
    ],
  },
  {
    id: 3,
    name: "Reworked Cargo Pants",
    price: 79.99,
    image: "/placeholder.svg?height=400&width=300",
    description:
      "Vintage cargo pants reworked with custom pockets and details. One size fits most with adjustable waist.",
    category: "Pants",
    isAvailable: true,
    productLink: "https://www.avito.ru/item/34567",
    size: "32/34",
    measurements: [
      { name: "Талия", value: "82 см" },
      { name: "Бедра", value: "106 см" },
      { name: "Длина", value: "102 см" },
      { name: "Ширина штанины", value: "22 см" },
    ],
  },
  {
    id: 4,
    name: "Embroidered Hoodie",
    price: 69.99,
    originalPrice: 89.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Premium cotton hoodie with hand-embroidered details. Each stitch pattern is unique.",
    category: "Outerwear",
    isAvailable: true,
    productLink: "https://www.avito.ru/item/45678",
    size: "XL",
    measurements: [
      { name: "Плечи", value: "50 см" },
      { name: "Грудь", value: "58 см" },
      { name: "Длина", value: "72 см" },
      { name: "Рукав", value: "65 см" },
    ],
  },
  {
    id: 5,
    name: "Upcycled Denim Bag",
    price: 45.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Handcrafted bag made from upcycled denim. Features unique pocket details and sturdy construction.",
    category: "Accessories",
    isNew: true,
    isAvailable: true,
    productLink: "https://www.avito.ru/item/56789",
    measurements: [
      { name: "Высота", value: "30 см" },
      { name: "Ширина", value: "40 см" },
      { name: "Глубина", value: "12 см" },
    ],
  },
  {
    id: 6,
    name: "Vintage Band Tee",
    price: 39.99,
    originalPrice: 54.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Authentic vintage band t-shirt from the 80s. Rare find in excellent condition.",
    category: "T-Shirts",
    isAvailable: true,
    productLink: "https://www.avito.ru/item/67890",
    size: "S",
    measurements: [
      { name: "Плечи", value: "42 см" },
      { name: "Грудь", value: "49 см" },
      { name: "Длина", value: "65 см" },
    ],
  },
  {
    id: 7,
    name: "Custom Leather Jacket",
    price: 189.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Handcrafted leather jacket with custom hardware and detailing. One-of-a-kind statement piece.",
    category: "Outerwear",
    isNew: true,
    isAvailable: true,
    productLink: "https://www.avito.ru/item/78901",
    size: "L",
    measurements: [
      { name: "Плечи", value: "48 см" },
      { name: "Грудь", value: "56 см" },
      { name: "Длина", value: "68 см" },
      { name: "Рукав", value: "63 см" },
    ],
  },
  {
    id: 8,
    name: "Patchwork Denim Skirt",
    price: 69.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Unique patchwork denim skirt made from vintage jeans. Each panel has its own character and history.",
    category: "Bottoms",
    isAvailable: true,
    productLink: "https://www.avito.ru/item/89012",
    size: "28",
    measurements: [
      { name: "Талия", value: "72 см" },
      { name: "Бедра", value: "96 см" },
      { name: "Длина", value: "60 см" },
    ],
  },
]

// Получение уникальных категорий из товаров
const getUniqueCategories = (products: Product[]) => {
  return Array.from(new Set(products.map((product) => product.category)))
}

// Начальные данные для акций
const initialPromotions = [
  {
    id: 1,
    title: "Unique Collection",
    description: "Exclusive one-of-a-kind pieces",
    image: "/placeholder.svg?height=200&width=400",
    discount: "NEW",
  },
  {
    id: 2,
    title: "Limited Edition",
    description: "Get them before they're gone",
    image: "/placeholder.svg?height=200&width=400",
    discount: "HOT",
  },
  {
    id: 3,
    title: "Flash Sale",
    description: "24 hours only! Special discounts",
    image: "/placeholder.svg?height=200&width=400",
    discount: "24HR",
    endDate: "Today",
  },
  {
    id: 4,
    title: "Vintage Finds",
    description: "Curated selection of unique vintage items",
    image: "/placeholder.svg?height=200&width=400",
    discount: "RARE",
  },
]

// Начальные данные для способов оплаты
const initialPaymentMethods = [
  {
    id: 1,
    name: "Перевод на карту",
    description: "Оплата переводом на банковскую карту",
    instructions: "Переведите указанную сумму на карту. После перевода нажмите кнопку 'Всё сделал'.",
    details: "5555 5555 5555 5555",
    enabled: true,
  },
  {
    id: 2,
    name: "Криптовалюта",
    description: "Оплата в Bitcoin или Ethereum",
    instructions: "Отправьте эквивалент указанной суммы на криптокошелек. После отправки нажмите кнопку 'Всё сделал'.",
    details: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
    enabled: true,
  },
]

// Начальные данные для заказов
const initialOrders = [
  {
    id: "order-1",
    orderNumber: "ORD-001",
    items: [
      {
        product: initialProducts[0],
        quantity: 1,
      },
    ],
    totalAmount: initialProducts[0].price,
    status: "completed",
    date: "2023-05-15T10:30:00Z",
    telegramUserId: 123456789,
    telegramUsername: "customer1",
    paymentMethod: "Перевод на карту",
  },
  {
    id: "order-2",
    orderNumber: "ORD-002",
    items: [
      {
        product: initialProducts[1],
        quantity: 2,
      },
      {
        product: initialProducts[3],
        quantity: 1,
      },
    ],
    totalAmount: initialProducts[1].price * 2 + initialProducts[3].price,
    status: "pending",
    date: "2023-05-20T14:45:00Z",
    telegramUserId: 987654321,
    telegramUsername: "customer2",
    paymentMethod: "Криптовалюта",
  },
]

// Создаем глобальное хранилище данных
export const globalStore = {
  products: initialProducts,
  categories: getUniqueCategories(initialProducts),
  promotions: initialPromotions,
  paymentMethods: initialPaymentMethods,
  deliveryMethods: [],
  orders: initialOrders,
  favorites: [],
  adminContact: "@Jericho_Services",
}

// Функция для получения данных из хранилища
export function getStoreData<T>(key: keyof typeof globalStore): T {
  return globalStore[key] as T
}

// Функция для обновления данных в хранилище
export function updateStoreData<T>(key: keyof typeof globalStore, data: T): void {
  globalStore[key] = data
  console.log(`Обновлено в globalStore: ${key}`, data)
}
