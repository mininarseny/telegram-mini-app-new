import { Inter, Roboto_Mono, Space_Grotesk } from "next/font/google"

export const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
})

export const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space-grotesk",
})

export const roboto_Mono = Roboto_Mono({
  subsets: ["latin"],
  variable: "--font-roboto-mono",
})

import { cn } from "@/lib/utils"

export const fontSans = cn(inter.variable, spaceGrotesk.variable, roboto_Mono.variable)
