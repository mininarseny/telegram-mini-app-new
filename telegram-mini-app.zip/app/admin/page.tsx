"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import type { Measurement } from "@/types/product"
import type { Order } from "@/types/order"
import { type globalStore, getStoreData, updateStoreData } from "@/lib/store"

// Admin authentication state
interface AdminAuth {
  isAuthenticated: boolean
  username: string
  password: string
}

// Product type definition
interface Product {
  id: number
  name: string
  price: number
  originalPrice?: number
  image: string
  additionalImages?: string[] // Добавляем поддержку нескольких изображений
  description: string
  category: string
  isNew?: boolean
  isAvailable: boolean
  productLink?: string
  size?: string
  measurements?: Measurement[]
}

// Promotion type definition
interface Promotion {
  id: number
  title: string
  description: string
  image: string
  discount: string
  endDate?: string
}

// Payment method type
interface PaymentMethod {
  id: number
  name: string
  description: string
  instructions: string
  details: string
  enabled: boolean
}

// Delivery method type
interface DeliveryMethod {
  id: number
  name: string
  description: string
  price: number
  enabled: boolean
}

// Sample products data
const initialProducts: Product[] = [
  {
    id: 1,
    name: "Vintage Denim Jacket",
    price: 89.99,
    originalPrice: 129.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Authentic vintage denim jacket from the 90s. One-of-a-kind piece with unique distressing and fading.",
    category: "Outerwear",
    isNew: true,
    isAvailable: true,
    productLink: "https://www.avito.ru/item/12345",
    size: "M",
    measurements: [
      { name: "Плечи", value: "45 см" },
      { name: "Грудь", value: "52 см" },
      { name: "Длина", value: "65 см" },
      { name: "Рукав", value: "60 см" },
    ],
  },
  {
    id: 2,
    name: "Hand-painted T-Shirt",
    price: 59.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Custom hand-painted t-shirt with original artwork. Each piece is unique and signed by the artist.",
    category: "T-Shirts",
    isNew: true,
    isAvailable: true,
    productLink: "https://www.avito.ru/item/23456",
    size: "L",
    measurements: [
      { name: "Плечи", value: "47 см" },
      { name: "Грудь", value: "54 см" },
      { name: "Длина", value: "70 см" },
    ],
  },
  {
    id: 3,
    name: "Reworked Cargo Pants",
    price: 79.99,
    image: "/placeholder.svg?height=300&width=300",
    description:
      "Vintage cargo pants reworked with custom pockets and details. One size fits most with adjustable waist.",
    category: "Pants",
    isAvailable: true,
    productLink: "https://www.avito.ru/item/34567",
    size: "32/34",
    measurements: [
      { name: "Талия", value: "82 см" },
      { name: "Бедра", value: "106 см" },
      { name: "Длина", value: "102 см" },
      { name: "Ширина штанины", value: "22 см" },
    ],
  },
  {
    id: 4,
    name: "Embroidered Hoodie",
    price: 69.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Premium cotton hoodie with hand-embroidered details. Each stitch pattern is unique.",
    category: "Outerwear",
    isAvailable: true,
    productLink: "https://www.avito.ru/item/45678",
    size: "XL",
    measurements: [
      { name: "Плечи", value: "50 см" },
      { name: "Грудь", value: "58 см" },
      { name: "Длина", value: "72 см" },
      { name: "Рукав", value: "65 см" },
    ],
  },
  {
    id: 5,
    name: "Upcycled Denim Bag",
    price: 45.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Handcrafted bag made from upcycled denim. Features unique pocket details and sturdy construction.",
    category: "Accessories",
    isNew: true,
    isAvailable: true,
    productLink: "https://www.avito.ru/item/56789",
    measurements: [
      { name: "Высота", value: "30 см" },
      { name: "Ширина", value: "40 см" },
      { name: "Глубина", value: "12 см" },
    ],
  },
  {
    id: 6,
    name: "Vintage Band Tee",
    price: 39.99,
    originalPrice: 54.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Authentic vintage band t-shirt from the 80s. Rare find in excellent condition.",
    category: "T-Shirts",
    isAvailable: true,
    productLink: "https://www.avito.ru/item/67890",
    size: "S",
    measurements: [
      { name: "Плечи", value: "42 см" },
      { name: "Грудь", value: "49 см" },
      { name: "Длина", value: "65 см" },
    ],
  },
  {
    id: 7,
    name: "Custom Leather Jacket",
    price: 189.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Handcrafted leather jacket with custom hardware and detailing. One-of-a-kind statement piece.",
    category: "Outerwear",
    isNew: true,
    isAvailable: true,
    productLink: "https://www.avito.ru/item/78901",
    size: "L",
    measurements: [
      { name: "Плечи", value: "48 см" },
      { name: "Грудь", value: "56 см" },
      { name: "Длина", value: "68 см" },
      { name: "Рукав", value: "63 см" },
    ],
  },
  {
    id: 8,
    name: "Patchwork Denim Skirt",
    price: 69.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Unique patchwork denim skirt made from vintage jeans. Each panel has its own character and history.",
    category: "Bottoms",
    isAvailable: true,
    productLink: "https://www.avito.ru/item/89012",
    size: "28",
    measurements: [
      { name: "Талия", value: "72 см" },
      { name: "Бедра", value: "96 см" },
      { name: "Длина", value: "60 см" },
    ],
  },
]

// Sample promotions data
const initialPromotions: Promotion[] = [
  {
    id: 1,
    title: "Unique Collection",
    description: "Exclusive one-of-a-kind pieces",
    image: "/placeholder.svg?height=200&width=400",
    discount: "NEW",
  },
  {
    id: 2,
    title: "Limited Edition",
    description: "Get them before they're gone",
    image: "/placeholder.svg?height=200&width=400",
    discount: "HOT",
  },
  {
    id: 3,
    title: "Flash Sale",
    description: "24 hours only! Special discounts",
    image: "/placeholder.svg?height=200&width=400",
    discount: "24HR",
    endDate: "Today",
  },
  {
    id: 4,
    title: "Vintage Finds",
    description: "Curated selection of unique vintage items",
    image: "/placeholder.svg?height=200&width=400",
    discount: "RARE",
  },
]

// Initial payment methods
const initialPaymentMethods: PaymentMethod[] = [
  {
    id: 1,
    name: "Перевод на карту",
    description: "Оплата переводом на банковскую карту",
    instructions: "Переведите указанную сумму на карту. После перевода нажмите кнопку 'Всё сделал'.",
    details: "5555 5555 5555 5555",
    enabled: true,
  },
  {
    id: 2,
    name: "Криптовалюта",
    description: "Оплата в Bitcoin или Ethereum",
    instructions: "Отправьте эквивалент указанной суммы на криптокошелек. После отправки нажмите кнопку 'Всё сделал'.",
    details: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
    enabled: true,
  },
]

// Initial delivery methods
const initialDeliveryMethods: DeliveryMethod[] = []

// Sample orders data
const initialOrders: Order[] = [
  {
    id: "order-1",
    orderNumber: "ORD-001",
    items: [
      {
        product: initialProducts[0],
        quantity: 1,
      },
    ],
    totalAmount: initialProducts[0].price,
    status: "completed",
    date: "2023-05-15T10:30:00Z",
    telegramUserId: 123456789,
    telegramUsername: "customer1",
    paymentMethod: "Перевод на карту",
  },
  {
    id: "order-2",
    orderNumber: "ORD-002",
    items: [
      {
        product: initialProducts[1],
        quantity: 2,
      },
      {
        product: initialProducts[3],
        quantity: 1,
      },
    ],
    totalAmount: initialProducts[1].price * 2 + initialProducts[3].price,
    status: "pending",
    date: "2023-05-20T14:45:00Z",
    telegramUserId: 987654321,
    telegramUsername: "customer2",
    paymentMethod: "Криптовалюта",
  },
]

// Get unique categories from products
const getUniqueCategories = (products: Product[]) => {
  return Array.from(new Set(products.map((product) => product.category)))
}

// Предопределенные шаблоны замеров для разных категорий
const measurementTemplates: Record<string, Measurement[]> = {
  Outerwear: [
    { name: "Плечи", value: "" },
    { name: "Грудь", value: "" },
    { name: "Длина", value: "" },
    { name: "Рукав", value: "" },
  ],
  "T-Shirts": [
    { name: "Плечи", value: "" },
    { name: "Грудь", value: "" },
    { name: "Длина", value: "" },
  ],
  Pants: [
    { name: "Талия", value: "" },
    { name: "Бедра", value: "" },
    { name: "Длина", value: "" },
    { name: "Ширина штанины", value: "" },
  ],
  Bottoms: [
    { name: "Талия", value: "" },
    { name: "Бедра", value: "" },
    { name: "Длина", value: "" },
  ],
  Accessories: [
    { name: "Высота", value: "" },
    { name: "Ширина", value: "" },
    { name: "Глубина", value: "" },
  ],
}

// Используем глобальное хранилище из lib/store.ts

// Функция для форматирования цены в рублях
const formatRubles = (price: number): string => {
  return `${price.toFixed(2)} ₽`
}

// Функция для сохранения данных в глобальное хранилище
const saveToStore = (key: keyof typeof globalStore, data: any) => {
  updateStoreData(key, data)
}

// Заменим заглушку функции handleLogin на реальную функцию проверки учетных данных

// Функция для входа в админ-панель
const handleLogin = (e: React.FormEvent, auth: AdminAuth, setAuth: React.Dispatch<React.SetStateAction<AdminAuth>>) => {
  e.preventDefault()
  // Проверяем учетные данные
  if (auth.username === "minin" && auth.password === "Ars_Min2008") {
    setAuth({ ...auth, isAuthenticated: true })
  } else {
    alert("Неверные учетные данные")
  }
}

// Dummy functions for goToStore, and handleLogout
const goToStore = () => {
  alert("Go to store function not implemented")
}

const handleLogout = () => {
  alert("Logout function not implemented")
}

export default function AdminPanel() {
  // Вернем исходное состояние авторизации в админке
  const [auth, setAuth] = useState<AdminAuth>({
    isAuthenticated: false,
    username: "",
    password: "",
  })

  const [products, setProducts] = useState<Product[]>(initialProducts)
  const [categories, setCategories] = useState<string[]>(getUniqueCategories(initialProducts))
  const [newCategory, setNewCategory] = useState<string>("")
  const [editingCategory, setEditingCategory] = useState<{ original: string; new: string } | null>(null)

  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: "",
    price: 0,
    originalPrice: undefined,
    image: "/placeholder.svg?height=300&width=300",
    additionalImages: [],
    description: "",
    category: "",
    isNew: false,
    isAvailable: true,
    productLink: "",
    size: "",
    measurements: [],
  })

  const [promotions, setPromotions] = useState<Promotion[]>(initialPromotions)
  const [newPromotion, setNewPromotion] = useState<Partial<Promotion>>({
    title: "",
    description: "",
    image: "/placeholder.svg?height=200&width=400",
    discount: "",
    endDate: "",
  })
  const [editingPromotion, setEditingPromotion] = useState<Promotion | null>(null)
  const [isAddingPromotion, setIsAddingPromotion] = useState(false)

  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(initialPaymentMethods)
  const [editingPaymentMethod, setEditingPaymentMethod] = useState<PaymentMethod | null>(null)
  const [isAddingPaymentMethod, setIsAddingPaymentMethod] = useState(false)
  const [newPaymentMethod, setNewPaymentMethod] = useState<Partial<PaymentMethod>>({
    name: "",
    description: "",
    instructions: "",
    details: "",
    enabled: true,
  })

  const [deliveryMethods, setDeliveryMethods] = useState<DeliveryMethod[]>([])
  const [editingDeliveryMethod, setEditingDeliveryMethod] = useState<DeliveryMethod | null>(null)
  const [isAddingDeliveryMethod, setIsAddingDeliveryMethod] = useState(false)
  const [newDeliveryMethod, setNewDeliveryMethod] = useState<Partial<DeliveryMethod>>({
    name: "",
    description: "",
    price: 0,
    enabled: true,
  })

  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [isAddingProduct, setIsAddingProduct] = useState(false)
  const [isAddingCategory, setIsAddingCategory] = useState(false)
  const [showPassword, setShowPassword] = useState(false)

  // Состояние для управления замерами
  const [newMeasurementName, setNewMeasurementName] = useState<string>("")
  const [newMeasurementValue, setNewMeasurementValue] = useState<string>("")

  // Добавим новое состояние для контактной информации администратора
  const [adminContact, setAdminContact] = useState<string>("@admin_username")

  // Добавим состояние для заказов
  const [orders, setOrders] = useState<Order[]>(initialOrders)
  const [editingOrder, setEditingOrder] = useState<Order | null>(null)
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>("all")

  // Состояние для загрузки изображений
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [uploadedAdditionalImages, setUploadedAdditionalImages] = useState<string[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)
  const additionalImagesInputRef = useRef<HTMLInputElement>(null)

  // State for client-side rendering
  const [isClient, setIsClient] = useState(false)

  // Load data from localStorage on component mount
  useEffect(() => {
    setIsClient(true)

    // Safely initialize the newProduct.category after we have loaded categories
    setNewProduct((prev) => ({
      ...prev,
      category: categories[0] || "",
    }))
  }, [])

  // Load all data after we've confirmed we're on the client
  useEffect(() => {
    if (!isClient) return

    // Загружаем данные из globalStore
    setProducts(getStoreData("products"))
    setCategories(getStoreData("categories"))
    setPromotions(getStoreData("promotions"))
    setPaymentMethods(getStoreData("paymentMethods"))
    setDeliveryMethods(getStoreData("deliveryMethods"))
    setOrders(getStoreData("orders"))
    setAdminContact(getStoreData("adminContact"))
  }, [isClient])

  const router = useRouter()

  // Обновляем шаблоны замеров при изменении категории
  useEffect(() => {
    if (newProduct.category && measurementTemplates[newProduct.category as string]) {
      setNewProduct((prevNewProduct) => ({
        ...prevNewProduct,
        measurements: JSON.parse(JSON.stringify(measurementTemplates[newProduct.category as string])),
      }))
    }
  }, [newProduct.category])

  // Add new category
  const addCategory = () => {
    if (newCategory.trim() === "") return
    if (categories.includes(newCategory.trim())) {
      alert("Эта категория уже существует")
      return
    }

    const updatedCategories = [...categories, newCategory.trim()]
    setCategories(updatedCategories)
    saveToStore("categories", updatedCategories)
    setNewCategory("")
    setIsAddingCategory(false)
  }

  // Edit category
  const updateCategory = () => {
    if (!editingCategory) return
    if (editingCategory.new.trim() === "") return
    if (categories.includes(editingCategory.new.trim()) && editingCategory.original !== editingCategory.new.trim()) {
      alert("Эта категория уже существует")
      return
    }

    const updatedCategories = categories.map((cat) =>
      cat === editingCategory.original ? editingCategory.new.trim() : cat,
    )

    // Update product categories as well
    const updatedProducts = products.map((product) => ({
      ...product,
      category: product.category === editingCategory.original ? editingCategory.new.trim() : product.category,
    }))

    setCategories(updatedCategories)
    setProducts(updatedProducts)
    saveToStore("categories", updatedCategories)
    saveToStore("products", updatedProducts)
    setEditingCategory(null)
  }

  // Delete category
  const deleteCategory = (category: string) => {
    if (window.confirm(`Вы уверены, что хотите удалить категорию "${category}"?`)) {
      const updatedCategories = categories.filter((cat) => cat !== category)

      // Set products in this category to a default category or remove them
      const updatedProducts = products.map((product) => {
        if (product.category === category) {
          return {
            ...product,
            category: updatedCategories[0] || "Без категории",
          }
        }
        return product
      })

      setCategories(updatedCategories)
      setProducts(updatedProducts)
      saveToStore("categories", updatedCategories)
      saveToStore("products", updatedProducts)
    }
  }

  // Функция для добавления нового замера
  const addMeasurement = () => {
    if (!newMeasurementName.trim() || !newMeasurementValue.trim()) return

    const newMeasurement: Measurement = {
      name: newMeasurementName.trim(),
      value: newMeasurementValue.trim(),
    }

    setNewProduct({
      ...newProduct,
      measurements: [...(newProduct.measurements || []), newMeasurement],
    })

    setNewMeasurementName("")
    setNewMeasurementValue("")
  }

  // Функция для удаления замера
  const removeMeasurement = (index: number) => {
    if (!newProduct.measurements) return

    const updatedMeasurements = [...newProduct.measurements]
    updatedMeasurements.splice(index, 1)

    setNewProduct({
      ...newProduct,
      measurements: updatedMeasurements,
    })
  }

  // Функция для обновления значения замера
  const updateMeasurementValue = (index: number, value: string) => {
    if (!newProduct.measurements) return

    const updatedMeasurements = [...newProduct.measurements]
    updatedMeasurements[index].value = value

    setNewProduct({
      ...newProduct,
      measurements: updatedMeasurements,
    })
  }

  // Функции для редактирования замеров существующего товара
  const addMeasurementToEditing = () => {
    if (!editingProduct || !newMeasurementName.trim() || !newMeasurementValue.trim()) return

    const newMeasurement: Measurement = {
      name: newMeasurementName.trim(),
      value: newMeasurementValue.trim(),
    }

    setEditingProduct({
      ...editingProduct,
      measurements: [...(editingProduct.measurements || []), newMeasurement],
    })

    setNewMeasurementName("")
    setNewMeasurementValue("")
  }

  const removeMeasurementFromEditing = (index: number) => {
    if (!editingProduct || !editingProduct.measurements) return

    const updatedMeasurements = [...editingProduct.measurements]
    updatedMeasurements.splice(index, 1)

    setEditingProduct({
      ...editingProduct,
      measurements: updatedMeasurements,
    })
  }

  const updateEditingMeasurementValue = (index: number, value: string) => {
    if (!editingProduct || !editingProduct.measurements) return

    const updatedMeasurements = [...editingProduct.measurements]
    updatedMeasurements[index].value = value

    setEditingProduct({
      ...editingProduct,
      measurements: updatedMeasurements,
    })
  }

  // Функция для обработки загрузки изображения
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        const imageUrl = event.target?.result as string
        setUploadedImage(imageUrl)

        // Обновляем newProduct или editingProduct в зависимости от контекста
        if (isAddingProduct) {
          setNewProduct({
            ...newProduct,
            image: imageUrl,
          })
        } else if (editingProduct) {
          setEditingProduct({
            ...editingProduct,
            image: imageUrl,
          })
        }
      }
      reader.readAsDataURL(file)
    }
  }

  // Функция для обработки загрузки дополнительных изображений
  const handleAdditionalImagesUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      const newImages: string[] = []
      let loadedCount = 0

      Array.from(files).forEach((file) => {
        const reader = new FileReader()
        reader.onload = (event) => {
          const imageUrl = event.target?.result as string
          newImages.push(imageUrl)
          loadedCount++

          // Когда все изображения загружены
          if (loadedCount === files.length) {
            setUploadedAdditionalImages([...uploadedAdditionalImages, ...newImages])

            // Обновляем newProduct или editingProduct в зависимости от контекста
            if (isAddingProduct) {
              setNewProduct({
                ...newProduct,
                additionalImages: [...(newProduct.additionalImages || []), ...newImages],
              })
            } else if (editingProduct) {
              setEditingProduct({
                ...editingProduct,
                additionalImages: [...(editingProduct.additionalImages || []), ...newImages],
              })
            }
          }
        }
        reader.readAsDataURL(file)
      })
    }
  }

  // Функция для удаления дополнительного изображения
  const removeAdditionalImage = (index: number) => {
    if (isAddingProduct && newProduct.additionalImages) {
      const updatedImages = [...newProduct.additionalImages]
      updatedImages.splice(index, 1)
      setNewProduct({
        ...newProduct,
        additionalImages: updatedImages,
      })
      setUploadedAdditionalImages(updatedImages)
    } else if (editingProduct && editingProduct.additionalImages) {
      const updatedImages = [...editingProduct.additionalImages]
      updatedImages.splice(index, 1)
      setEditingProduct({
        ...editingProduct,
        additionalImages: updatedImages,
      })
      setUploadedAdditionalImages(updatedImages)
    }
  }

  // Add new product
  const addProduct = () => {
    if (!newProduct.name || !newProduct.price || !newProduct.description || !newProduct.category) {
      alert("Пожалуйста, заполните все обязательные поля")
      return
    }

    const newId = Math.max(...products.map((p) => p.id), 0) + 1

    const productToAdd: Product = {
      id: newId,
      name: newProduct.name || "",
      price: Number(newProduct.price) || 0,
      originalPrice: newProduct.originalPrice ? Number(newProduct.originalPrice) : undefined,
      image: newProduct.image || "/placeholder.svg?height=300&width=300",
      additionalImages:
        newProduct.additionalImages && newProduct.additionalImages.length > 0 ? newProduct.additionalImages : undefined,
      description: newProduct.description || "",
      category: newProduct.category || categories[0] || "",
      isNew: newProduct.isNew || false,
      isAvailable: newProduct.isAvailable !== undefined ? newProduct.isAvailable : true,
      productLink: newProduct.productLink || "",
      size: newProduct.size || undefined,
      measurements:
        newProduct.measurements && newProduct.measurements.length > 0
          ? newProduct.measurements.filter((m) => m.name && m.value)
          : undefined,
    }

    const updatedProducts = [...products, productToAdd]
    setProducts(updatedProducts)
    saveToStore("products", updatedProducts)

    setNewProduct({
      name: "",
      price: 0,
      originalPrice: undefined,
      image: "/placeholder.svg?height=300&width=300",
      additionalImages: [],
      description: "",
      category: categories[0] || "",
      isNew: false,
      isAvailable: true,
      productLink: "",
      size: "",
      measurements: [],
    })
    setUploadedImage(null)
    setUploadedAdditionalImages([])
    setIsAddingProduct(false)
  }

  // Update product
  const updateProduct = () => {
    if (!editingProduct) return

    if (!editingProduct.name || !editingProduct.price || !editingProduct.description || !editingProduct.category) {
      alert("Пожалуйста, заполните все обязательные поля")
      return
    }

    // Фильтруем замеры, чтобы убрать пустые
    const filteredMeasurements = editingProduct.measurements?.filter((m) => m.name && m.value) || undefined

    const updatedProduct = {
      ...editingProduct,
      measurements: filteredMeasurements,
    }

    const updatedProducts = products.map((product) => (product.id === editingProduct.id ? updatedProduct : product))

    setProducts(updatedProducts)
    saveToStore("products", updatedProducts)
    setEditingProduct(null)
    setUploadedImage(null)
    setUploadedAdditionalImages([])
  }

  // Delete product
  const deleteProduct = (id: number) => {
    if (typeof window === "undefined") return

    if (window.confirm("Вы уверены, что хотите удалить этот товар?")) {
      const updatedProducts = products.filter((product) => product.id !== id)
      setProducts(updatedProducts)
      saveToStore("products", updatedProducts)
    }
  }

  // Toggle product availability
  const toggleProductAvailability = (id: number) => {
    const updatedProducts = products.map((product) =>
      product.id === id ? { ...product, isAvailable: !product.isAvailable } : product,
    )
    setProducts(updatedProducts)
    saveToStore("products", updatedProducts)
  }

  // Add new promotion
  const addPromotion = () => {
    if (!newPromotion.title || !newPromotion.description || !newPromotion.discount) {
      alert("Пожалуйста, заполните все обязательные поля")
      return
    }

    const newId = Math.max(...promotions.map((p) => p.id), 0) + 1

    const promotionToAdd: Promotion = {
      id: newId,
      title: newPromotion.title || "",
      description: newPromotion.description || "",
      image: newPromotion.image || "/placeholder.svg?height=200&width=400",
      discount: newPromotion.discount || "",
      endDate: newPromotion.endDate,
    }

    const updatedPromotions = [...promotions, promotionToAdd]
    setPromotions(updatedPromotions)
    saveToStore("promotions", updatedPromotions)

    setNewPromotion({
      title: "",
      description: "",
      image: "/placeholder.svg?height=200&width=400",
      discount: "",
      endDate: "",
    })
    setIsAddingPromotion(false)
  }

  // Update promotion
  const updatePromotion = () => {
    if (!editingPromotion) return

    if (!editingPromotion.title || !editingPromotion.description || !editingPromotion.discount) {
      alert("Пожалуйста, заполните все обязательные поля")
      return
    }

    const updatedPromotions = promotions.map((promotion) =>
      promotion.id === editingPromotion.id ? editingPromotion : promotion,
    )

    setPromotions(updatedPromotions)
    saveToStore("promotions", updatedPromotions)
    setEditingPromotion(null)
  }

  // Delete promotion
  const deletePromotion = (id: number) => {
    if (window.confirm("Вы уверены, что хотите удалить эту акцию?")) {
      const updatedPromotions = promotions.filter((promotion) => promotion.id !== id)
      setPromotions(updatedPromotions)
      saveToStore("promotions", updatedPromotions)
    }
  }

  // Add new payment method
  const addPaymentMethod = () => {
    if (!newPaymentMethod.name || !newPaymentMethod.description) {
      alert("Пожалуйста, заполните все обязательные поля")
      return
    }

    const newId = Math.max(...paymentMethods.map((p) => p.id), 0) + 1

    const paymentMethodToAdd: PaymentMethod = {
      id: newId,
      name: newPaymentMethod.name || "",
      description: newPaymentMethod.description || "",
      instructions: newPaymentMethod.instructions || "",
      details: newPaymentMethod.details || "",
      enabled: newPaymentMethod.enabled !== undefined ? newPaymentMethod.enabled : true,
    }

    const updatedPaymentMethods = [...paymentMethods, paymentMethodToAdd]
    setPaymentMethods(updatedPaymentMethods)
    saveToStore("paymentMethods", updatedPaymentMethods)

    setNewPaymentMethod({
      name: "",
      description: "",
      instructions: "",
      details: "",
      enabled: true,
    })
    setIsAddingPaymentMethod(false)
  }

  // Update payment method
  const updatePaymentMethod = () => {
    if (!editingPaymentMethod) return

    if (!editingPaymentMethod.name || !editingPaymentMethod.description) {
      alert("Пожалуйста, заполните все обязательные поля")
      return
    }

    const updatedPaymentMethods = paymentMethods.map((method) =>
      method.id === editingPaymentMethod.id ? editingPaymentMethod : method,
    )

    setPaymentMethods(updatedPaymentMethods)
    saveToStore("paymentMethods", updatedPaymentMethods)
    setEditingPaymentMethod(null)
  }

  // Delete payment method
  const deletePaymentMethod = (id: number) => {
    if (window.confirm("Вы уверены, что хотите удалить этот способ оплаты?")) {
      const updatedPaymentMethods = paymentMethods.filter((method) => method.id !== id)
      setPaymentMethods(updatedPaymentMethods)
      saveToStore("paymentMethods", updatedPaymentMethods)
    }
  }

  // Toggle payment method enabled status
  const togglePaymentMethodEnabled = (id: number) => {
    const updatedPaymentMethods = paymentMethods.map((method) =>
      method.id === id ? { ...method, enabled: !method.enabled } : method,
    )
    setPaymentMethods(updatedPaymentMethods)
    saveToStore("paymentMethods", updatedPaymentMethods)
  }

  // Add new delivery method
  const addDeliveryMethod = () => {
    if (!newDeliveryMethod.name || !newDeliveryMethod.description) {
      alert("Пожалуйста, заполните все обязательные поля")
      return
    }

    const newId = Math.max(...(deliveryMethods.map((d) => d.id) || [0]), 0) + 1

    const deliveryMethodToAdd: DeliveryMethod = {
      id: newId,
      name: newDeliveryMethod.name || "",
      description: newDeliveryMethod.description || "",
      price: Number(newDeliveryMethod.price) || 0,
      enabled: newDeliveryMethod.enabled !== undefined ? newDeliveryMethod.enabled : true,
    }

    const updatedDeliveryMethods = [...deliveryMethods, deliveryMethodToAdd]
    setDeliveryMethods(updatedDeliveryMethods)
    saveToStore("deliveryMethods", updatedDeliveryMethods)

    setNewDeliveryMethod({
      name: "",
      description: "",
      price: 0,
      enabled: true,
    })
    setIsAddingDeliveryMethod(false)
  }

  // Update delivery method
  const updateDeliveryMethod = () => {
    if (!editingDeliveryMethod) return

    if (!editingDeliveryMethod.name || !editingDeliveryMethod.description) {
      alert("Пожалуйста, заполните все обязательные поля")
      return
    }

    const updatedDeliveryMethods = deliveryMethods.map((method) =>
      method.id === editingDeliveryMethod.id ? editingDeliveryMethod : method,
    )

    setDeliveryMethods(updatedDeliveryMethods)
    saveToStore("deliveryMethods", updatedDeliveryMethods)
    setEditingDeliveryMethod(null)
  }

  // Delete delivery method
  const deleteDeliveryMethod = (id: number) => {
    if (window.confirm("Вы уверены, что хотите удалить этот способ доставки?")) {
      const updatedDeliveryMethods = deliveryMethods.filter((method) => method.id !== id)
      setDeliveryMethods(updatedDeliveryMethods)
      saveToStore("deliveryMethods", updatedDeliveryMethods)
    }
  }

  // Toggle delivery method enabled status
  const toggleDeliveryMethodEnabled = (id: number) => {
    const updatedDeliveryMethods = deliveryMethods.map((method) =>
      method.id === id ? { ...method, enabled: !method.enabled } : method,
    )
    setDeliveryMethods(updatedDeliveryMethods)
    saveToStore("deliveryMethods", updatedDeliveryMethods)
  }

  // Update order status
  const updateOrderStatus = (orderId: string, status: "pending" | "completed" | "cancelled") => {
    const updatedOrders = orders.map((order) => (order.id === orderId ? { ...order, status } : order))
    setOrders(updatedOrders)
    saveToStore("orders", updatedOrders)
  }

  // Restore products from cancelled order
  const restoreProductsFromOrder = (order: Order) => {
    if (window.confirm("Вы уверены, что хотите восстановить эти товары?")) {
      // Update products to make them available again
      const updatedProducts = [...products]

      order.items.forEach((item) => {
        const productIndex = updatedProducts.findIndex((p) => p.id === item.product.id)
        if (productIndex !== -1) {
          updatedProducts[productIndex] = { ...updatedProducts[productIndex], isAvailable: true }
        } else {
          // If product was deleted, add it back
          updatedProducts.push({ ...item.product, isAvailable: true })
        }
      })

      setProducts(updatedProducts)
      saveToStore("products", updatedProducts)
    }
  }

  // Update admin contact
  const updateAdminContact = () => {
    saveToStore("adminContact", adminContact)
    alert("Контактная информация администратора успешно обновлена!")
  }

  // Render login form
  if (!auth.isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-100 dark:bg-zinc-900 p-4">
        <div className="bg-white dark:bg-zinc-800 p-8 rounded-lg shadow-lg max-w-md w-full">
          <h1 className="text-2xl font-bold mb-6 text-center">Вход в панель администратора</h1>
          <form onSubmit={(e) => handleLogin(e, auth, setAuth)} className="space-y-4">
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                Имя пользователя
              </label>
              <input
                type="text"
                id="username"
                value={auth.username}
                onChange={(e) => setAuth({ ...auth, username: e.target.value })}
                className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                required
              />
            </div>
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                Пароль
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  id="password"
                  value={auth.password}
                  onChange={(e) => setAuth({ ...auth, password: e.target.value })}
                  className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 text-zinc-500 dark:text-zinc-400"
                >
                  {showPassword ? "Скрыть" : "Показать"}
                </button>
              </div>
            </div>
            <button
              type="submit"
              className="w-full bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 py-2 rounded-md font-medium"
            >
              Войти
            </button>
          </form>
          <div className="mt-4 text-center">
            <button
              onClick={goToStore}
              className="text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100 text-sm"
            >
              Вернуться в магазин
            </button>
          </div>
        </div>
      </div>
    )
  }

  // Admin panel UI
  return (
    <div className="min-h-screen bg-zinc-100 dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100">
      <header className="bg-white dark:bg-zinc-800 shadow-md p-4 sticky top-0 z-10">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold">Панель администратора Jericho</h1>
          <div className="flex items-center gap-4">
            <button
              onClick={goToStore}
              className="px-3 py-1 text-sm border border-zinc-300 dark:border-zinc-600 rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-700"
            >
              Просмотр магазина
            </button>
            <button
              onClick={handleLogout}
              className="px-3 py-1 text-sm bg-red-600 hover:bg-red-700 text-white rounded-md"
            >
              Выйти
            </button>
          </div>
        </div>
      </header>

      <main className="container mx-auto py-6 px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white dark:bg-zinc-800 p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-2">Товары</h2>
            <p className="text-zinc-600 dark:text-zinc-400 mb-4">Всего товаров: {products.length}</p>
            <button
              onClick={() => setIsAddingProduct(true)}
              className="w-full bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 py-2 rounded-md font-medium"
            >
              Добавить новый товар
            </button>
          </div>

          <div className="bg-white dark:bg-zinc-800 p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-2">Категории</h2>
            <p className="text-zinc-600 dark:text-zinc-400 mb-4">Всего категорий: {categories.length}</p>
            <button
              onClick={() => setIsAddingCategory(true)}
              className="w-full bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 py-2 rounded-md font-medium"
            >
              Добавить новую категорию
            </button>
          </div>

          <div className="bg-white dark:bg-zinc-800 p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-2">Заказы</h2>
            <p className="text-zinc-600 dark:text-zinc-400 mb-4">Всего заказов: {orders.length}</p>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-green-100 dark:bg-green-900/30 p-2 rounded-md">
                <p className="font-bold text-green-800 dark:text-green-400">
                  {orders.filter((order) => order.status === "completed").length}
                </p>
                <p className="text-xs text-green-600 dark:text-green-500">Выполнено</p>
              </div>
              <div className="bg-yellow-100 dark:bg-yellow-900/30 p-2 rounded-md">
                <p className="font-bold text-yellow-800 dark:text-yellow-400">
                  {orders.filter((order) => order.status === "pending").length}
                </p>
                <p className="text-xs text-yellow-600 dark:text-yellow-500">В обработке</p>
              </div>
              <div className="bg-red-100 dark:bg-red-900/30 p-2 rounded-md">
                <p className="font-bold text-red-800 dark:text-red-400">
                  {orders.filter((order) => order.status === "cancelled").length}
                </p>
                <p className="text-xs text-red-600 dark:text-red-500">Отменено</p>
              </div>
            </div>
          </div>
        </div>

        {/* Admin Contact Information */}
        <div className="bg-white dark:bg-zinc-800 p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-xl font-bold mb-4">Контактная информация администратора</h2>
          <div className="flex items-end gap-4">
            <div className="flex-1">
              <label htmlFor="adminContact" className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                Имя пользователя в Telegram
              </label>
              <input
                type="text"
                id="adminContact"
                value={adminContact}
                onChange={(e) => setAdminContact(e.target.value)}
                className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                placeholder="@username"
              />
            </div>
            <button
              onClick={updateAdminContact}
              className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 rounded-md font-medium"
            >
              Обновить
            </button>
          </div>
          <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-2">
            Эта контактная информация будет показана клиентам после оформления заказа.
          </p>
        </div>

        {/* Categories Management */}
        <div className="bg-white dark:bg-zinc-800 p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-xl font-bold mb-4">Управление категориями</h2>

          {isAddingCategory ? (
            <div className="mb-6 p-4 border border-zinc-200 dark:border-zinc-700 rounded-lg">
              <h3 className="font-medium mb-3">Добавить новую категорию</h3>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="flex-1 p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                  placeholder="Название категории"
                />
                <button
                  onClick={addCategory}
                  className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 rounded-md font-medium"
                >
                  Добавить
                </button>
                <button
                  onClick={() => setIsAddingCategory(false)}
                  className="px-4 py-2 border border-zinc-300 dark:border-zinc-600 rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-700"
                >
                  Отмена
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setIsAddingCategory(true)}
              className="mb-6 px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 rounded-md font-medium"
            >
              Добавить новую категорию
            </button>
          )}

          <div className="space-y-2">
            {categories.map((category) =>
              editingCategory && editingCategory.original === category ? (
                <div key={category} className="flex gap-2 p-3 border border-zinc-200 dark:border-zinc-700 rounded-lg">
                  <input
                    type="text"
                    value={editingCategory.new}
                    onChange={(e) => setEditingCategory({ ...editingCategory, new: e.target.value })}
                    className="flex-1 p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                  />
                  <button
                    onClick={updateCategory}
                    className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded-md"
                  >
                    Сохранить
                  </button>
                  <button
                    onClick={() => setEditingCategory(null)}
                    className="px-3 py-1 border border-zinc-300 dark:border-zinc-600 rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-700"
                  >
                    Отмена
                  </button>
                </div>
              ) : (
                <div
                  key={category}
                  className="flex justify-between items-center p-3 border border-zinc-200 dark:border-zinc-700 rounded-lg"
                >
                  <span>{category}</span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setEditingCategory({ original: category, new: category })}
                      className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-md"
                    >
                      Изменить
                    </button>
                    <button
                      onClick={() => deleteCategory(category)}
                      className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-md"
                    >
                      Удалить
                    </button>
                  </div>
                </div>
              ),
            )}
          </div>
        </div>

        {/* Products Management */}
        <div className="bg-white dark:bg-zinc-800 p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-xl font-bold mb-4">Управление товарами</h2>

          {isAddingProduct ? (
            <div className="mb-6 p-4 border border-zinc-200 dark:border-zinc-700 rounded-lg">
              <h3 className="font-medium mb-3">Добавить новый товар</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Название</label>
                  <input
                    type="text"
                    value={newProduct.name || ""}
                    onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                    className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                    placeholder="Название товара"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Категория</label>
                  <select
                    value={newProduct.category || ""}
                    onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                    className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                  >
                    <option value="">Выберите категорию</option>
                    {categories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Цена (₽)</label>
                  <input
                    type="number"
                    value={newProduct.price || ""}
                    onChange={(e) => setNewProduct({ ...newProduct, price: Number(e.target.value) })}
                    className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                    placeholder="0.00"
                    step="0.01"
                    min="0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                    Исходная цена (₽, необязательно)
                  </label>
                  <input
                    type="number"
                    value={newProduct.originalPrice || ""}
                    onChange={(e) =>
                      setNewProduct({
                        ...newProduct,
                        originalPrice: e.target.value ? Number(e.target.value) : undefined,
                      })
                    }
                    className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                    placeholder="0.00"
                    step="0.01"
                    min="0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                    Основное изображение
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newProduct.image || ""}
                      onChange={(e) => setNewProduct({ ...newProduct, image: e.target.value })}
                      className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                      placeholder="/placeholder.svg?height=300&width=300"
                    />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3 py-1 bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 rounded-md"
                    >
                      Загрузить
                    </button>
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleImageUpload}
                      accept="image/*"
                      className="hidden"
                    />
                  </div>
                  {uploadedImage && (
                    <div className="mt-2">
                      <img
                        src={uploadedImage || "/placeholder.svg"}
                        alt="Предпросмотр"
                        className="h-20 w-20 object-cover rounded-md"
                      />
                    </div>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                    Дополнительные изображения
                  </label>
                  <div className="flex gap-2">
                    <button
                      onClick={() => additionalImagesInputRef.current?.click()}
                      className="w-full px-3 py-2 bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 rounded-md"
                    >
                      Загрузить дополнительные изображения
                    </button>
                    <input
                      type="file"
                      ref={additionalImagesInputRef}
                      onChange={handleAdditionalImagesUpload}
                      accept="image/*"
                      multiple
                      className="hidden"
                    />
                  </div>
                  {newProduct.additionalImages && newProduct.additionalImages.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {newProduct.additionalImages.map((img, idx) => (
                        <div key={idx} className="relative">
                          <img
                            src={img || "/placeholder.svg"}
                            alt={`Изображение ${idx + 1}`}
                            className="h-20 w-20 object-cover rounded-md"
                          />
                          <button
                            onClick={() => removeAdditionalImage(idx)}
                            className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full w-5 h-5 flex items-center justify-center"
                          >
                            ×
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                    Размер (необязательно)
                  </label>
                  <input
                    type="text"
                    value={newProduct.size || ""}
                    onChange={(e) => setNewProduct({ ...newProduct, size: e.target.value })}
                    className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                    placeholder="S, M, L, XL и т.д."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                    Ссылка на товар (необязательно)
                  </label>
                  <input
                    type="text"
                    value={newProduct.productLink || ""}
                    onChange={(e) => setNewProduct({ ...newProduct, productLink: e.target.value })}
                    className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                    placeholder="https://www.avito.ru/item/12345"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Описание</label>
                  <textarea
                    value={newProduct.description || ""}
                    onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                    className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                    placeholder="Описание товара"
                    rows={3}
                  ></textarea>
                </div>
                <div>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={newProduct.isNew || false}
                      onChange={(e) => setNewProduct({ ...newProduct, isNew: e.target.checked })}
                      className="mr-2"
                    />
                    <span className="text-sm font-medium text-zinc-700 dark:text-zinc-300">Отметить как новинку</span>
                  </label>
                </div>
                <div>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={newProduct.isAvailable !== undefined ? newProduct.isAvailable : true}
                      onChange={(e) => setNewProduct({ ...newProduct, isAvailable: e.target.checked })}
                      className="mr-2"
                    />
                    <span className="text-sm font-medium text-zinc-700 dark:text-zinc-300">Доступен</span>
                  </label>
                </div>
              </div>

              {/* Measurements section */}
              <div className="mb-4">
                <h4 className="font-medium mb-2">Замеры</h4>
                <div className="space-y-2 mb-3">
                  {newProduct.measurements?.map((measurement, index) => (
                    <div key={index} className="flex gap-2">
                      <input
                        type="text"
                        value={measurement.name}
                        readOnly
                        className="flex-1 p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100"
                      />
                      <input
                        type="text"
                        value={measurement.value}
                        onChange={(e) => updateMeasurementValue(index, e.target.value)}
                        className="flex-1 p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                        placeholder="Значение"
                      />
                      <button
                        onClick={() => removeMeasurement(index)}
                        className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-md"
                      >
                        Удалить
                      </button>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newMeasurementName}
                    onChange={(e) => setNewMeasurementName(e.target.value)}
                    className="flex-1 p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                    placeholder="Название (например, Грудь, Талия)"
                  />
                  <input
                    type="text"
                    value={newMeasurementValue}
                    onChange={(e) => setNewMeasurementValue(e.target.value)}
                    className="flex-1 p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                    placeholder="Значение (например, 42 см)"
                  />
                  <button
                    onClick={addMeasurement}
                    className="px-3 py-1 bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 rounded-md"
                  >
                    Добавить
                  </button>
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setIsAddingProduct(false)}
                  className="px-4 py-2 border border-zinc-300 dark:border-zinc-600 rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-700"
                >
                  Отмена
                </button>
                <button
                  onClick={addProduct}
                  className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 rounded-md font-medium"
                >
                  Добавить товар
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setIsAddingProduct(true)}
              className="mb-6 px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 rounded-md font-medium"
            >
              Добавить новый товар
            </button>
          )}

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-zinc-200 dark:divide-zinc-700">
              <thead className="bg-zinc-50 dark:bg-zinc-800">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                    Товар
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                    Категория
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                    Цена
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                    Статус
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                    Действия
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-zinc-800 divide-y divide-zinc-200 dark:divide-zinc-700">
                {products.map((product) => (
                  <tr key={product.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-10 w-10 flex-shrink-0 rounded-md overflow-hidden">
                          <img
                            src={product.image || "/placeholder.svg?height=300&width=300"}
                            alt={product.name}
                            className="h-10 w-10 object-cover"
                          />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-zinc-900 dark:text-zinc-100">{product.name}</div>
                          <div className="text-sm text-zinc-500 dark:text-zinc-400">
                            {product.size ? `Размер: ${product.size}` : "Без размера"}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-zinc-900 dark:text-zinc-100">{product.category}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-zinc-900 dark:text-zinc-100">{formatRubles(product.price)}</div>
                      {product.originalPrice && (
                        <div className="text-xs text-zinc-500 dark:text-zinc-400 line-through">
                          {formatRubles(product.originalPrice)}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          product.isAvailable
                            ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
                            : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"
                        }`}
                      >
                        {product.isAvailable ? "Доступен" : "Продан"}
                      </span>
                      {product.isNew && (
                        <span className="ml-2 px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400">
                          Новинка
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => setEditingProduct(product)}
                        className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-3"
                      >
                        Изменить
                      </button>
                      <button
                        onClick={() => toggleProductAvailability(product.id)}
                        className={`${
                          product.isAvailable
                            ? "text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                            : "text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300"
                        } mr-3`}
                      >
                        {product.isAvailable ? "Отметить как проданный" : "Отметить как доступный"}
                      </button>
                      <button
                        onClick={() => deleteProduct(product.id)}
                        className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                      >
                        Удалить
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Edit Product Modal */}
        {editingProduct && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white dark:bg-zinc-800 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <h3 className="text-xl font-bold mb-4">Изменить товар</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Название</label>
                    <input
                      type="text"
                      value={editingProduct.name}
                      onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                      className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Категория</label>
                    <select
                      value={editingProduct.category}
                      onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                      className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                    >
                      {categories.map((category) => (
                        <option key={category} value={category}>
                          {category}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Цена (₽)</label>
                    <input
                      type="number"
                      value={editingProduct.price}
                      onChange={(e) =>
                        setEditingProduct({
                          ...editingProduct,
                          price: Number(e.target.value),
                        })
                      }
                      className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                      step="0.01"
                      min="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                      Исходная цена (₽, необязательно)
                    </label>
                    <input
                      type="number"
                      value={editingProduct.originalPrice || ""}
                      onChange={(e) =>
                        setEditingProduct({
                          ...editingProduct,
                          originalPrice: e.target.value ? Number(e.target.value) : undefined,
                        })
                      }
                      className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                      step="0.01"
                      min="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                      Основное изображение
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={editingProduct.image}
                        onChange={(e) => setEditingProduct({ ...editingProduct, image: e.target.value })}
                        className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                      />
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="px-3 py-1 bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 rounded-md"
                      >
                        Загрузить
                      </button>
                    </div>
                    <div className="mt-2">
                      <img
                        src={editingProduct.image || "/placeholder.svg"}
                        alt="Предпросмотр"
                        className="h-20 w-20 object-cover rounded-md"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                      Дополнительные изображения
                    </label>
                    <div className="flex gap-2">
                      <button
                        onClick={() => additionalImagesInputRef.current?.click()}
                        className="w-full px-3 py-2 bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 rounded-md"
                      >
                        Загрузить дополнительные изображения
                      </button>
                    </div>
                    {editingProduct.additionalImages && editingProduct.additionalImages.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-2">
                        {editingProduct.additionalImages.map((img, idx) => (
                          <div key={idx} className="relative">
                            <img
                              src={img || "/placeholder.svg"}
                              alt={`Изображение ${idx + 1}`}
                              className="h-20 w-20 object-cover rounded-md"
                            />
                            <button
                              onClick={() => removeAdditionalImage(idx)}
                              className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full w-5 h-5 flex items-center justify-center"
                            >
                              ×
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                      Размер (необязательно)
                    </label>
                    <input
                      type="text"
                      value={editingProduct.size || ""}
                      onChange={(e) => setEditingProduct({ ...editingProduct, size: e.target.value })}
                      className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                      Ссылка на товар (необязательно)
                    </label>
                    <input
                      type="text"
                      value={editingProduct.productLink || ""}
                      onChange={(e) => setEditingProduct({ ...editingProduct, productLink: e.target.value })}
                      className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Описание</label>
                    <textarea
                      value={editingProduct.description}
                      onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                      className="w-full p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                      rows={3}
                    ></textarea>
                  </div>
                  <div>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={editingProduct.isNew || false}
                        onChange={(e) => setEditingProduct({ ...editingProduct, isNew: e.target.checked })}
                        className="mr-2"
                      />
                      <span className="text-sm font-medium text-zinc-700 dark:text-zinc-300">Отметить как новинку</span>
                    </label>
                  </div>
                  <div>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={editingProduct.isAvailable}
                        onChange={(e) => setEditingProduct({ ...editingProduct, isAvailable: e.target.checked })}
                        className="mr-2"
                      />
                      <span className="text-sm font-medium text-zinc-700 dark:text-zinc-300">Доступен</span>
                    </label>
                  </div>
                </div>

                {/* Measurements section */}
                <div className="mb-4">
                  <h4 className="font-medium mb-2">Замеры</h4>
                  <div className="space-y-2 mb-3">
                    {editingProduct.measurements?.map((measurement, index) => (
                      <div key={index} className="flex gap-2">
                        <input
                          type="text"
                          value={measurement.name}
                          readOnly
                          className="flex-1 p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100"
                        />
                        <input
                          type="text"
                          value={measurement.value}
                          onChange={(e) => updateEditingMeasurementValue(index, e.target.value)}
                          className="flex-1 p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                        />
                        <button
                          onClick={() => removeMeasurementFromEditing(index)}
                          className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-md"
                        >
                          Удалить
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newMeasurementName}
                      onChange={(e) => setNewMeasurementName(e.target.value)}
                      className="flex-1 p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                      placeholder="Название (например, Грудь, Талия)"
                    />
                    <input
                      type="text"
                      value={newMeasurementValue}
                      onChange={(e) => setNewMeasurementValue(e.target.value)}
                      className="flex-1 p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
                      placeholder="Значение (например, 42 см)"
                    />
                    <button
                      onClick={addMeasurementToEditing}
                      className="px-3 py-1 bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 rounded-md"
                    >
                      Добавить
                    </button>
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setEditingProduct(null)}
                    className="px-4 py-2 border border-zinc-300 dark:border-zinc-600 rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-700"
                  >
                    Отмена
                  </button>
                  <button
                    onClick={updateProduct}
                    className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 rounded-md font-medium"
                  >
                    Сохранить изменения
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Orders Management */}
        <div className="bg-white dark:bg-zinc-800 p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-xl font-bold mb-4">Управление заказами</h2>

          <div className="mb-4">
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Фильтр по статусу</label>
            <select
              value={orderStatusFilter}
              onChange={(e) => setOrderStatusFilter(e.target.value)}
              className="p-2 border border-zinc-300 dark:border-zinc-600 rounded-md bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100"
            >
              <option value="all">Все заказы</option>
              <option value="pending">В обработке</option>
              <option value="completed">Выполненные</option>
              <option value="cancelled">Отмененные</option>
            </select>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-zinc-200 dark:divide-zinc-700">
              <thead className="bg-zinc-50 dark:bg-zinc-800">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                    Заказ №
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                    Дата
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                    Клиент
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                    Сумма
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                    Статус
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                    Действия
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-zinc-800 divide-y divide-zinc-200 dark:divide-zinc-700">
                {orders
                  .filter((order) => orderStatusFilter === "all" || order.status === orderStatusFilter)
                  .map((order) => (
                    <tr key={order.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-zinc-900 dark:text-zinc-100">{order.orderNumber}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-zinc-500 dark:text-zinc-400">
                          {new Date(order.date).toLocaleDateString()}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-zinc-900 dark:text-zinc-100">
                          {order.telegramUsername ? `@${order.telegramUsername}` : `ID: ${order.telegramUserId}`}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
                          {formatRubles(order.totalAmount)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            order.status === "completed"
                              ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
                              : order.status === "pending"
                                ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400"
                                : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"
                          }`}
                        >
                          {order.status === "completed"
                            ? "Выполнен"
                            : order.status === "pending"
                              ? "В обработке"
                              : "Отменен"}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        {order.status === "pending" && (
                          <>
                            <button
                              onClick={() => updateOrderStatus(order.id, "completed")}
                              className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300 mr-3"
                            >
                              Выполнить
                            </button>
                            <button
                              onClick={() => updateOrderStatus(order.id, "cancelled")}
                              className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                            >
                              Отменить
                            </button>
                          </>
                        )}
                        {order.status === "completed" && (
                          <button
                            onClick={() => updateOrderStatus(order.id, "pending")}
                            className="text-yellow-600 hover:text-yellow-900 dark:text-yellow-400 dark:hover:text-yellow-300"
                          >
                            Вернуть в обработку
                          </button>
                        )}
                        {order.status === "cancelled" && (
                          <>
                            <button
                              onClick={() => updateOrderStatus(order.id, "pending")}
                              className="text-yellow-600 hover:text-yellow-900 dark:text-yellow-400 dark:hover:text-yellow-300 mr-3"
                            >
                              Вернуть в обработку
                            </button>
                            <button
                              onClick={() => restoreProductsFromOrder(order)}
                              className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300"
                            >
                              Восстановить товары
                            </button>
                          </>
                        )}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  )
}
