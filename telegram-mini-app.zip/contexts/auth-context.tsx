"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

// Тип данных пользователя Telegram
export interface TelegramUser {
  id: number
  first_name: string
  last_name?: string
  username?: string
  photo_url?: string
  auth_date?: number
  hash?: string
}

// Интерфейс контекста авторизации
interface AuthContextType {
  user: TelegramUser | null
  isAuthenticated: boolean
  isLoading: boolean
  login: () => void
  logout: () => void
}

// Создаем контекст с безопасными значениями по умолчанию
const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: () => {},
  logout: () => {},
})

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<TelegramUser | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isTelegramAvailable, setIsTelegramAvailable] = useState(false)

  // Проверяем доступность Telegram WebApp API и получаем данные пользователя
  useEffect(() => {
    const checkTelegramAuth = () => {
      if (typeof window !== "undefined" && window.Telegram?.WebApp) {
        setIsTelegramAvailable(true)

        // Сообщаем Telegram, что Mini App готово
        window.Telegram.WebApp.ready()

        // Расширяем Mini App на полную высоту
        window.Telegram.WebApp.expand()

        // Получаем данные пользователя, если они доступны
        if (window.Telegram.WebApp.initDataUnsafe && window.Telegram.WebApp.initDataUnsafe.user) {
          const telegramUser = window.Telegram.WebApp.initDataUnsafe.user
          setUser({
            id: telegramUser.id,
            first_name: telegramUser.first_name,
            last_name: telegramUser.last_name,
            username: telegramUser.username,
            photo_url: telegramUser.photo_url,
            auth_date: window.Telegram.WebApp.initDataUnsafe.auth_date,
            hash: window.Telegram.WebApp.initDataUnsafe.hash,
          })
        }
      }

      setIsLoading(false)
    }

    checkTelegramAuth()
  }, [])

  // Функция для входа (в реальном приложении здесь может быть запрос к серверу)
  const login = () => {
    if (isTelegramAvailable) {
      // Если Telegram WebApp доступен, но пользователь не авторизован,
      // можно попросить пользователя открыть приложение в Telegram
      alert("Пожалуйста, откройте это приложение через Telegram для авторизации")
    } else {
      // Если Telegram недоступен, создаем тестового пользователя
      setUser({
        id: 12345678,
        first_name: "Тестовый",
        last_name: "Пользователь",
        username: "test_user",
        photo_url: undefined,
        auth_date: Math.floor(Date.now() / 1000),
        hash: "test_hash",
      })
    }
  }

  // Функция для выхода
  const logout = () => {
    setUser(null)
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
