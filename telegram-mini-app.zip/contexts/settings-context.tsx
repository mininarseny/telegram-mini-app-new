"use client"

import type React from "react"
import { createContext, useContext, useState, type ReactNode } from "react"

// Типы валют и языков
export type Currency = "RUB" | "USD"
export type Language = "ru" | "en"

// Интерфейс контекста настроек
interface SettingsContextType {
  currency: Currency
  language: Language
  toggleCurrency: () => void
  toggleLanguage: () => void
  formatPrice: (price: number, originalPrice?: number) => string
  t: (key: string) => string
}

// Создаем контекст
const SettingsContext = createContext<SettingsContextType | undefined>(undefined)

// Курс обмена: 1 USD = X RUB
const EXCHANGE_RATE = 92

// Словарь переводов
const translations: Record<Language, Record<string, string>> = {
  ru: {
    // Общие
    "app.title": "Jericho",
    "app.continue_shopping": "Продолжить покупки",
    "app.details": "Подробнее",
    "app.sold_out": "Продано",
    "app.add_to_cart": "Добавить в корзину",
    "app.shop_now": "Купить сейчас",
    "app.size": "Размер",
    "app.category": "Категория",
    "app.unique_item": "Уникальный товар",
    "app.unique_item_desc":
      "Это уникальный товар, доступный только в одном размере и цвете. Когда он закончится, его больше не будет!",
    "app.measurements": "Замеры",

    // Корзина
    "cart.title": "Корзина",
    "cart.empty": "Ваша корзина пуста",
    "cart.empty_desc": "Похоже, вы еще не добавили товары в корзину",
    "cart.remove": "Удалить",
    "cart.subtotal": "Сумма",
    "cart.total": "Итого",
    "cart.checkout": "Перейти к оплате",

    // Оплата
    "payment.title": "Оплата заказа",
    "payment.desc": "Для завершения покупки переведите {price} на карту",
    "payment.card_number": "Номер карты",
    "payment.item": "Товар",
    "payment.amount": "Сумма",
    "payment.link_desc": "После оплаты вы можете получить товар по ссылке ниже",
    "payment.go_to_item": "Перейти к товару",
    "payment.back_to_shop": "Вернуться в магазин",
    "payment.select_method": "Выберите способ оплаты",
    "payment.no_methods": "Нет доступных способов оплаты",
    "payment.copied": "Скопировано!",
    "payment.currency": "Валюта",
    "payment.completed": "Всё сделал",
    "payment.avito_warning": "⚠️ Важно! Сначала оформите заказ на Авито, и только после этого переводите деньги.",
    "payment.order_number": "Номер заказа",
    "payment.order_number_desc": "Укажите этот номер при оплате в комментарии к переводу",
    "payment.comment": "Комментарий к переводу",
    "payment.order": "Заказ",

    // Промо
    "promo.recommended": "Рекомендуемые товары",

    // Confirmation
    "confirmation.title": "Спасибо за заказ!",
    "confirmation.desc": "Ваш заказ успешно оформлен.",
    "confirmation.shipping": "Заказ будет отправлен в течение 3 дней.",
    "confirmation.questions": "Есть вопросы?",
    "confirmation.contact_admin": "По всем вопросам обращайтесь к администратору: {contact}",
    "confirmation.contact_in_bot": "По всем вопросам обращайтесь к администратору, указанному в боте.",
    "confirmation.continue_shopping": "Вернуться в магазин",
    "confirmation.order_details": "Детали заказа",
    "confirmation.order_number": "Номер заказа",
    "confirmation.order_reference": "Сохраните этот номер для отслеживания вашего заказа",

    // Поиск
    "search.placeholder": "Поиск товаров...",
    "search.result": "результат",
    "search.results": "результатов",
    "search.no_results": "Ничего не найдено",

    // Избранное
    "favorites.title": "Избранное",
    "favorites.empty": "Список избранного пуст",
    "favorites.empty_desc": "Добавьте товары в избранное, чтобы они отображались здесь",
    "favorites.back": "Назад к товарам",
    "favorites.remove": "Удалить из избранного",
    "favorites.add": "Добавить в избранное",

    // История заказов
    "orders.title": "История заказов",
    "orders.empty": "У вас пока нет заказов",
    "orders.empty_desc": "Здесь будут отображаться ваши заказы после покупки",
    "orders.back": "Назад к товарам",
    "orders.order": "Заказ",
    "orders.status_completed": "Выполнен",
    "orders.status_pending": "В обработке",
    "orders.status_cancelled": "Отменен",
    "orders.items": "Товаров",
    "orders.payment_method": "Способ оплаты",
    "orders.show_details": "Показать детали",
    "orders.hide_details": "Скрыть детали",
    "orders.order_items": "Товары в заказе",
    "orders.total": "Итого",
    "orders.my_orders": "Мои заказы",

    // Отзывы
    "reviews.title": "Отзывы",
    "reviews.add": "Добавить отзыв",
    "reviews.write": "Написать отзыв",
    "reviews.name": "Ваше имя",
    "reviews.name_placeholder": "Введите ваше имя",
    "reviews.rating": "Оценка",
    "reviews.comment": "Комментарий",
    "reviews.comment_placeholder": "Поделитесь вашим мнением о товаре",
    "reviews.submit": "Отправить",
    "reviews.cancel": "Отмена",
    "reviews.no_reviews": "У этого товара пока нет отзывов. Будьте первым!",

    // Доставка
    "delivery.title": "Выберите способ доставки",
    "delivery.russian_post": "Почта России",
    "delivery.boxberry": "Boxberry",
    "delivery.russian_post_desc": "Доставка в любую точку России",
    "delivery.boxberry_desc": "Доставка до пункта выдачи",
  },
  en: {
    // General
    "app.title": "Jericho",
    "app.continue_shopping": "Continue Shopping",
    "app.details": "Details",
    "app.sold_out": "Sold Out",
    "app.add_to_cart": "Add to Cart",
    "app.shop_now": "Shop Now",
    "app.size": "Size",
    "app.category": "Category",
    "app.unique_item": "Unique Item",
    "app.unique_item_desc":
      "This is a unique item available in one size and color only. Once it's gone, it's gone forever!",
    "app.measurements": "Measurements",

    // Cart
    "cart.title": "Cart",
    "cart.empty": "Your cart is empty",
    "cart.empty_desc": "Looks like you haven't added any items to your cart yet",
    "cart.remove": "Remove",
    "cart.subtotal": "Subtotal",
    "cart.total": "Total",
    "cart.checkout": "Checkout",

    // Payment
    "payment.title": "Order Payment",
    "payment.desc": "To complete your purchase, transfer {price} to the card",
    "payment.card_number": "Card Number",
    "payment.item": "Item",
    "payment.amount": "Amount",
    "payment.link_desc": "After payment, you can get your item using the link below",
    "payment.go_to_item": "Go to Item",
    "payment.back_to_shop": "Back to Shop",
    "payment.select_method": "Select payment method",
    "payment.no_methods": "No payment methods available",
    "payment.copied": "Copied!",
    "payment.currency": "Currency",
    "payment.completed": "Payment Completed",
    "payment.avito_warning": "⚠️ Important! First place an order on Avito, and only then transfer the money.",
    "payment.order_number": "Order Number",
    "payment.order_number_desc": "Please include this number in the payment comment",
    "payment.comment": "Payment comment",
    "payment.order": "Order",

    // Promo
    "promo.recommended": "Recommended Items",

    // Confirmation
    "confirmation.title": "Thank you for your order!",
    "confirmation.desc": "Your order has been successfully placed.",
    "confirmation.shipping": "Your order will be shipped within 3 days.",
    "confirmation.questions": "Have questions?",
    "confirmation.contact_admin": "For any questions, please contact the administrator: {contact}",
    "confirmation.contact_in_bot": "For any questions, please contact the administrator specified in the bot.",
    "confirmation.continue_shopping": "Back to Shop",
    "confirmation.order_details": "Order Details",
    "confirmation.order_number": "Order Number",
    "confirmation.order_reference": "Please save this number for tracking your order",

    // Search
    "search.placeholder": "Search products...",
    "search.result": "result",
    "search.results": "results",
    "search.no_results": "No results found",

    // Favorites
    "favorites.title": "Favorites",
    "favorites.empty": "Your favorites list is empty",
    "favorites.empty_desc": "Add products to your favorites to see them here",
    "favorites.back": "Back to products",
    "favorites.remove": "Remove from favorites",
    "favorites.add": "Add to favorites",

    // Order History
    "orders.title": "Order History",
    "orders.empty": "You don't have any orders yet",
    "orders.empty_desc": "Your orders will appear here after you make a purchase",
    "orders.back": "Back to products",
    "orders.order": "Order",
    "orders.status_completed": "Completed",
    "orders.status_pending": "Pending",
    "orders.status_cancelled": "Cancelled",
    "orders.items": "Items",
    "orders.payment_method": "Payment method",
    "orders.show_details": "Show details",
    "orders.hide_details": "Hide details",
    "orders.order_items": "Order items",
    "orders.total": "Total",
    "orders.my_orders": "My Orders",

    // Reviews
    "reviews.title": "Reviews",
    "reviews.add": "Add review",
    "reviews.write": "Write a review",
    "reviews.name": "Your name",
    "reviews.name_placeholder": "Enter your name",
    "reviews.rating": "Rating",
    "reviews.comment": "Comment",
    "reviews.comment_placeholder": "Share your thoughts about the product",
    "reviews.submit": "Submit",
    "reviews.cancel": "Cancel",
    "reviews.no_reviews": "This product has no reviews yet. Be the first!",

    // Delivery
    "delivery.title": "Choose delivery method",
    "delivery.russian_post": "Russian Post",
    "delivery.boxberry": "Boxberry",
    "delivery.russian_post_desc": "Delivery to any point in Russia",
    "delivery.boxberry_desc": "Delivery to pickup point",
  },
}

// Провайдер контекста
export const SettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currency, setCurrency] = useState<Currency>("RUB")
  const [language, setLanguage] = useState<Language>("ru")

  // Переключение валюты
  const toggleCurrency = () => {
    setCurrency((prev) => (prev === "RUB" ? "USD" : "RUB"))
  }

  // Переключение языка
  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "ru" ? "en" : "ru"))
  }

  // Форматирование цены в зависимости от выбранной валюты
  const formatPrice = (price: number, originalPrice?: number): string => {
    if (currency === "USD") {
      const usdPrice = price / EXCHANGE_RATE
      const usdOriginalPrice = originalPrice ? originalPrice / EXCHANGE_RATE : undefined

      return originalPrice
        ? `$${usdPrice.toFixed(2)}${usdOriginalPrice ? ` $${usdOriginalPrice.toFixed(2)}` : ""}`
        : `$${usdPrice.toFixed(2)}`
    } else {
      return originalPrice
        ? `${price.toFixed(2)} ₽${originalPrice ? ` ${originalPrice.toFixed(2)} ₽` : ""}`
        : `${price.toFixed(2)} ₽`
    }
  }

  // Функция перевода
  const t = (key: string): string => {
    return translations[language][key] || key
  }

  // Значение контекста
  const value = {
    currency,
    language,
    toggleCurrency,
    toggleLanguage,
    formatPrice,
    t,
  }

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>
}

// Хук для использования контекста
export const useSettings = (): SettingsContextType => {
  const context = useContext(SettingsContext)
  if (context === undefined) {
    throw new Error("useSettings must be used within a SettingsProvider")
  }
  return context
}
