"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface FavoritesContextType {
  favorites: number[]
  addToFavorites: (productId: number) => void
  removeFromFavorites: (productId: number) => void
  isFavorite: (productId: number) => boolean
  toggleFavorite: (productId: number) => void
}

// Create context with safe default values
const FavoritesContext = createContext<FavoritesContextType>({
  favorites: [],
  addToFavorites: () => {},
  removeFromFavorites: () => {},
  isFavorite: () => false,
  toggleFavorite: () => {},
})

// In-memory storage for favorites
const memoryStore = {
  favorites: [] as number[],
}

export const FavoritesProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Start with empty favorites array
  const [favorites, setFavorites] = useState<number[]>([])
  const [mounted, setMounted] = useState(false)

  // Mark that we're mounted
  useEffect(() => {
    setMounted(true)
  }, [])

  const addToFavorites = (productId: number) => {
    setFavorites((prev) => {
      if (prev.includes(productId)) {
        return prev
      }
      const newFavorites = [...prev, productId]
      memoryStore.favorites = newFavorites
      return newFavorites
    })
  }

  const removeFromFavorites = (productId: number) => {
    setFavorites((prev) => {
      const newFavorites = prev.filter((id) => id !== productId)
      memoryStore.favorites = newFavorites
      return newFavorites
    })
  }

  const isFavorite = (productId: number) => {
    return favorites.includes(productId)
  }

  const toggleFavorite = (productId: number) => {
    if (isFavorite(productId)) {
      removeFromFavorites(productId)
    } else {
      addToFavorites(productId)
    }
  }

  return (
    <FavoritesContext.Provider value={{ favorites, addToFavorites, removeFromFavorites, isFavorite, toggleFavorite }}>
      {children}
    </FavoritesContext.Provider>
  )
}

export const useFavorites = (): FavoritesContextType => {
  const context = useContext(FavoritesContext)
  return context
}
